<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * This file replaces the legacy STATEMENTS section in db/install.xml,
 * lib.php/modulename_install() post installation hook and partially defaults.php
 *
 * @package    mod_proficiency
 * @copyright  2011 Your Name <your@email.adress>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

/**
 * Post installation procedure
 *
 * @see upgrade_plugins_modules()
 */
function xmldb_proficiency_install() {

	global $CFG, $OUTPUT, $DB;

	$conexion = conectarBD();
	
	$dir_subida = $CFG->dirroot . '/mod/proficiency/uploads/';

        $filenames = array(
		'trivial', 
		'global', 
		'starwars'
		);

        foreach ($filenames as $filename) {



        	$fichero_xml = $dir_subida . $filename . ".xml" ;

			$dom = new DOMDocument();
			$data = file_get_contents($fichero_xml);
			$dom->loadXML($data);


   			$addquiz = "INSERT INTO " . $CFG->prefix . "proficiency_quizzes(userid, name, intro, timecreated) values (0, '".$filename."', '".$fichero_xml."', ". time().")";
   			$resultado = $conexion->query($addquiz);
   			if (!$resultado) 
     			return false;

   			$newquizid = $conexion->insert_id;

			$preguntas = $dom->getElementsByTagName('preguntas')->item(0);

			foreach($preguntas->getElementsByTagName('pregunta') as $pregunta){
					$preguntatexto = $pregunta->getElementsByTagName('preguntatexto')->item(0);
					$respuesta = $pregunta->getElementsByTagName('respuesta')->item(0);
					$categoria = $pregunta->getElementsByTagName('categoria')->item(0);

					$insertsql = "INSERT INTO  " . $CFG->prefix . "proficiency_questions(quizid, pregunta, respuesta, categoria) VALUES (".$newquizid.",'".eliminarEspacios($preguntatexto->nodeValue)."', '". eliminarEspacios($respuesta->nodeValue) . "', '". eliminarEspacios($categoria->nodeValue) ."')";	
			        if ($conexion->query($insertsql) !== TRUE) {
			     		echo "Error creating table: " . $conexion->error;
					}   		
					
			}
			        
		}
	



}

function conectarBD()
{

	global $CFG;

	/** El nombre de tu base de datos */
define('DB_NAME', $CFG->dbname);

/** Tu nombre de usuario de MySQL */
define('DB_USER', $CFG->dbuser);

/** Tu contraseña de MySQL */
define('DB_PASSWORD', $CFG->dbpass);

/** Host de MySQL (es muy probable que no necesites cambiarlo) */
define('DB_HOST', $CFG->dbhost);

/** Codificación de caracteres para la base de datos. */
define('DB_CHARSET', 'utf8');

	/* create a connection object which is not connected */
	$mysqli = mysqli_init();

	/* set connection options */
	$mysqli->options(MYSQLI_OPT_LOCAL_INFILE, true);

	/* connect to server */
	$mysqli->real_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
	$mysqli->set_charset(DB_CHARSET);
		
	/* check connection */
	if (mysqli_connect_errno()) {
			printf("Conexión fallida: %s\n", mysqli_connect_error());
			exit();
	}		
	return $mysqli;
}

function eliminarEspacios($texto){
	return trim($texto," \t\n\0\x0B");

}

/**
 * Post installation recovery procedure
 *
 * @see upgrade_plugins_modules()
 */
function xmldb_proficiency_install_recovery() {
}
