<?php

require_once(dirname(dirname(dirname(__FILE__))).'/config.php');


$nombrequiz = $_POST['nombrequiz'];
$tablaquiz = $_POST['nombretablaquiz'];


/** El nombre de tu base de datos */
define('DB_NAME', $CFG->dbname);

/** Tu nombre de usuario de MySQL */
define('DB_USER', $CFG->dbuser);

/** Tu contraseña de MySQL */
define('DB_PASSWORD', $CFG->dbpass);

/** Host de MySQL (es muy probable que no necesites cambiarlo) */
define('DB_HOST', $CFG->dbhost);

/** Codificación de caracteres para la base de datos. */
define('DB_CHARSET', 'utf8');



function conectarBD()
{
	/* create a connection object which is not connected */
	$mysqli = mysqli_init();

	/* set connection options */
	$mysqli->options(MYSQLI_OPT_LOCAL_INFILE, true);

	/* connect to server */
	$mysqli->real_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
	$mysqli->set_charset(DB_CHARSET);
		
	/* check connection */
	if (mysqli_connect_errno()) {
			printf("Conexión fallida: %s\n", mysqli_connect_error());
			exit();
	}		
	return $mysqli;
}




$dir_subida = '/var/www/html/moodle26/mod/proficiency/uploads/';
$fichero_subido = $dir_subida . basename($_FILES['file']['name']);


if (!move_uploaded_file($_FILES['file']['tmp_name'], $fichero_subido))
  	echo "¡Posible ataque de subida de ficheros!\n";


function eliminarEspacios($texto){
	return trim($texto," \t\n\0\x0B");

}

$conexion = conectarBD();

$dom = new DOMDocument();
$data = file_get_contents($fichero_subido);
$dom->loadXML($data);

$droptable = "DROP TABLE IF EXISTS " . $tablaquiz;

if ($conexion->query($droptable) !== TRUE) {
     echo "Error creating table: " . $conexion->error;
}

$createsql = "CREATE TABLE " . $tablaquiz . " (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
pregunta VARCHAR(255) NOT NULL,
respuesta VARCHAR(255) NOT NULL,
categoria VARCHAR(10) NOT NULL
)";



if ($conexion->query($createsql) !== TRUE) {
     echo "Error creating table: " . $conexion->error;
}

$preguntas = $dom->getElementsByTagName('preguntas')->item(0);

foreach($preguntas->getElementsByTagName('pregunta') as $pregunta){
		$preguntatexto = $pregunta->getElementsByTagName('preguntatexto')->item(0);
		$respuesta = $pregunta->getElementsByTagName('respuesta')->item(0);
		$categoria = $pregunta->getElementsByTagName('categoria')->item(0);

		$insertsql = "INSERT INTO " . $tablaquiz ."(pregunta, respuesta, categoria) VALUES ('".eliminarEspacios($preguntatexto->nodeValue)."', '". eliminarEspacios($respuesta->nodeValue) . "', '". eliminarEspacios($categoria->nodeValue) ."')";	
        if ($conexion->query($insertsql) !== TRUE) {
     		echo "Error creating table: " . $conexion->error;
		}   		
		
}



$conexion->close();
?>
