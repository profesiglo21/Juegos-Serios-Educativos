<?php
require_once(dirname(dirname(dirname(__FILE__))).'/config.php');

$fuente_id = $_POST["fuen"];

$lista_categ = array();

/** El nombre de tu base de datos */
define('DB_NAME', $CFG->dbname);

/** Tu nombre de usuario de MySQL */
define('DB_USER', $CFG->dbuser);

/** Tu contraseña de MySQL */
define('DB_PASSWORD', $CFG->dbpass);

/** Host de MySQL (es muy probable que no necesites cambiarlo) */
define('DB_HOST', $CFG->dbhost);

/** Codificación de caracteres para la base de datos. */
define('DB_CHARSET', 'utf8');



function conectarBD()
{
	/* create a connection object which is not connected */
	$mysqli = mysqli_init();

	/* set connection options */
	$mysqli->options(MYSQLI_OPT_LOCAL_INFILE, true);

	/* connect to server */
	$mysqli->real_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
	$mysqli->set_charset(DB_CHARSET);
		
	/* check connection */
	if (mysqli_connect_errno()) {
			printf("Conexión fallida: %s\n", mysqli_connect_error());
			exit();
	}		
	return $mysqli;
}

//establecer conexión con la base de datos
$conexion = conectarBD();

//escribir la consulta a realizar
$sql = "SELECT DISTINCT categoria FROM " . $CFG->prefix . "proficiency_questions WHERE quizid = " . $fuente_id ;

//ejecutar la consulta y devolver error si lo hubiera
if (!$resultado=$conexion->query($sql)) {
     echo "Error creating table: " . $conexion->error;
}


//obtener los resultados
while ($categoria = $resultado->fetch_assoc()) {
	$lista_categ[] = $categoria["categoria"];
}

$conexion->close();
//echo var_dump($lista_categ);
echo json_encode($lista_categ);
die();




?>
