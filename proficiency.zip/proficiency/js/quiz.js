$(document).ready(function() 
{  
   $.get('pinicial.html', function(data){
          modal.open({content: data});            
   });

	//estructura de tipo array para recoger los datos que vienen del .php
	var Quizids = new Array;
  var Quiznames = new Array;
  var Categorias = new Array;
  var Questions = new Array;
	var Answers = new Array;

  //datos de preferencias
  var fuenteelegida;
  var categoriaelegida;
	var qnumber = 0;
	var aciertos = 0;
	var fallos = 0;
  var pistamax;
	var quizFinalizado = false;
  var finQuizSiAhorcado = false;
  var puntuacion = 0;
   
   //imágenes hangman 
   var hangmancuerda = new Image();
   var hangmancabeza = new Image();   
   var hangmancuerpo = new Image();
   var hangmanbrazos = new Image();
   var hangmanpiernas = new Image();
   var hangmanentero = new Image();

   //ahorcado canvas
   var qcanvas = $("#ahorcado")[0];
   var context = qcanvas.getContext("2d");

   hangmancuerda.onload = function() {
         context.drawImage(hangmancuerda, 5, 40);      
   };

   hangmancuerda.src = 'images/hangman/cuerda.png';
   hangmancabeza.src = 'images/hangman/cabeza.png';    
   hangmancuerpo.src = 'images/hangman/cuerpo.png'; 
   hangmanbrazos.src = 'images/hangman/brazos.png';
   hangmanpiernas.src = 'images/hangman/piernas.png';
   hangmanentero.src = 'images/hangman/entero.png';

     getQuizzes();    
  
    

    

   function Init(){   
    
   	  document.getElementById("quiz").style.display="block";
      document.getElementById("penalizaciones").style.display="block";
      document.getElementById("continuar").style.display= "none";
      
      var $radios = $('input:checkbox[name=ahorcadofin]');
      if($radios.is(':checked') === true) {
         finQuizSiAhorcado = true;
      }
   
      context.textBaseline = "middle";
      context.font = "1.2em San-serif,Arial";
      context.fillStyle ="rgb(25,25,25)";
      context.fillText("¡Bienvenido!:",7,15);      
      context.fillStyle ="rgb(63,123,164)";      
      context.fillText(document.getElementById("nombre").value,10,30);
         
   }

        


   function resetAjustes(){

   		document.getElementById("ajustes").style.display= "block";
     	document.getElementById("scorepanel").style.display= "none"; 
     	document.getElementById("quiz").style.display= "none";
     	document.getElementById("ahorcado").style.display= "none";
         $('#categoria').empty();
         $('#categoria').append('<option value="null">-- Ninguna categoría seleccionada --</option>'); 
        
         $('input:radio[name=puntuacion]').removeAttr('checked');
         document.getElementById("maxpreguntas").innerHTML = 0;
         document.getElementById("num_preguntas").disabled=true;
         document.getElementById("valorpreg").innerHTML = 0;

   }


    function getQuizzes(){
        fuente = $("#fuente").val();

        $.ajax({
            type: "POST",
            url: "obtenerquizzes.php",
            dataType: "json",
            error: function(){
                 alert("error petición ajax");
                 resetAjustes();
            },
            success: function(data){
              //recuperar información de fichero .php que envia lista de valores
              Quizids = data[0]; 
              Quiznames = data[1];  
            
            $('#fuente').empty();
            $('#fuente').append('<option value="null">-- Ninguna Cuestionario seleccionada --</option>'); 

            for (var i=0; i < Quiznames.length; i++) {
                $('#fuente').append('<option value="'+ Quizids[i] +'">' + Quiznames[i] +'</option>'); 
               
            }
            $('#fuente').append('<option value="0">PROFICIENCY! - Todas la categorías</option>');    
               

              

            }
    });      
   }

   function getCategorias(){
        fuente = $("#fuente").val();
        
      	$.ajax({
            type: "POST",
            url: "obtenercategorias.php",
            data: "fuen="+fuente,
            dataType: "json",
            error: function(){
                 alert("error petición ajax");
                 resetAjustes();
            },
            success: function(data){
              //recuperar información de fichero .php que envia lista de valores
              Categorias = data;

            $('#categoria').empty();
         	  $('#categoria').append('<option value="null">-- Ninguna categoría seleccionada --</option>');	

         	  if(fuente == 1){
            	  $.each(Categorias, function(key,value){
            	  		switch(value){
            	  			case 'G':
            	  					descripcion = 'G - Geografía';
            	  					break;   	  					
            	  			case 'E':
            	  					descripcion = 'E - Entretenimiento';
            	  					break;   	  					
            	  			case 'H':
            	  					descripcion = 'H - Historia';
            	  					break;
            	  			case 'AL':
            	  					descripcion = 'AL - Arte y Literatura';
            	  					break;
            	  			case 'C':
            	  					descripcion = 'C - Ciencia';
            	  					break;
            	  		}

            	  		$('#categoria').append($('<option>',{
            	  		    value:value,
            	  			text:descripcion
            	      }));  	   
            	   });

                 $('#categoria').append('<option value="0">Todas la categorías</option>');   

                 $(function() {
                     var $radios = $('input:radio[name=puntuacion]');
                     $radios.filter('[value=100]').prop('checked', true);
                    
                  }); 
               }
               else if(fuente == 2){
                var $radios = $('input:radio[name=puntuacion]');
                $radios.filter('[value=200]').prop('checked', true);
                $.each(Categorias, function(key,value){
                    switch(value){
                      case 'A':
                          descripcion = 'A - Azul (Nivel Bajo)';                     
                          
                          break;                
                      case 'R':
                          descripcion = 'L - Lila (Nivel Medio)';
                          
                          break;                
                      case 'L':
                          descripcion = 'R - Rosa (Nivel Avanzado)';
                          
                          break;                      
                    }

                    $('#categoria').append($('<option>',{
                        value:value,
                      text:descripcion
                    }));       
                });

                 $('#categoria').append('<option value="0">Todas la categorías</option>');                 
               }
               else if(fuente == 3){

                $.each(Categorias, function(key,value){
                    switch(value){
                      case 'P':
                          descripcion = 'P - Personajes';                     
                          
                          break;                
                      case 'AV':
                          descripcion = 'AV - Armas y Vehículos';
                          
                          break;                
                      case 'H':
                          descripcion = 'H - Historia';
                          
                          break;   
                      case 'G':
                          descripcion = 'G - Geografía';                     
                          
                          break;                
                      case 'DC':
                          descripcion = 'DC - Droides, Criaturas y Extraterrestres';
                          
                          break;                
                      case 'V':
                          descripcion = 'V - Varios';
                          
                          break;                       
                    }

                    $('#categoria').append($('<option>',{
                        value:value,
                      text:descripcion
                    }));       
                 });

                 $('#categoria').append('<option value="0">Todas la categorías</option>');   

                  $(function() {
                     var $radios = $('input:radio[name=puntuacion]');
                    
                          $radios.filter('[value=500]').prop('checked', true);        

                 
               });
            }
            else{

              $.each(Categorias, function(key,value){
                    
                    $('#categoria').append($('<option>',{
                        value:value,
                        text:value
                    }));       
                 });

                 $('#categoria').append('<option value="0">Todas la categorías</option>');   

                 $(function() {
                     var $radios = $('input:radio[name=puntuacion]');
                     $radios.filter('[value=100]').prop('checked', true);
                    
                  }); 

            }
            }
	  });   	 
   }

   
   function getNumPreguntas() {
    //obtenemos los datos introducido en el campo del formulario
   fuente = $("#fuente").val();
   if(fuente == 0)
      categoria = '0';
   else
      categoria = $("#categoria").val(); 
                                                            
   //hace la búsqueda
   $.ajax({
            type: "POST",
            url: "obtenernumpreguntas.php",
            data: "fuen="+fuente+"&cat="+categoria,
            dataType: "html",
            error: function(){
                  alert("error petición ajax");
                  resetAjustes();
            },
            success: function(data){
                 //recuperar información de fichero .php que envia lista de valores
             
                  document.getElementById("maxpreguntas").innerHTML = data;
                  
                  if(Number(data)> 0){
                       document.getElementById("num_preguntas").setAttribute("max", data);
                       document.getElementById("num_preguntas").setAttribute("min", 1);
                       document.getElementById("num_preguntas").disabled=false;
                       document.getElementById("botonplay").disabled = false;
                       document.getElementById("valorpreg").innerHTML =document.getElementById("num_preguntas").value;
                  }
                  else
                     document.getElementById("num_preguntas").disabled=true;

                                                        
            }
     }); 
   } 


	
  function getPreguntas() {
    //obtenemos los datos introducido en el campo del formulario
	fuente = $("#fuente").val();
	categoria = $("#categoria").val();
	npreguntas = $("#num_preguntas").val();

	//alert("fuen="+fuente+"&cat="+categoria+"&npreg="+npreguntas);                                                     
	//hace la búsqueda
	$.ajax({
            type: "POST",
            url: "obtenerpreguntas.php",
            data: "fuen="+fuente+"&cat="+categoria+"&npreg="+npreguntas,
            dataType: "json",
            error: function(){
                  alert("error petición ajax (obtenerpreguntas.php)");
            	  
            },
            success: function(data){
            	  //recuperar información de fichero .php que envia lista de valores
                  Questions = data[0];
                  Answers = data[1];
                  idpregunta = qnumber + 1;
                  pregunta = Questions[qnumber];
                  document.getElementById("idpregunta").innerHTML = "Pregunta " + idpregunta + ":";
		          document.getElementById("pregunta").innerHTML = pregunta;
                  respuesta=Answers[qnumber];
                  //respuesta_normalizada = normalize(respuesta);
                  //respuesta_oculta = respuesta_normalizada.toLowerCase().replace(/[a-z,0-9]/gi,'_');
                  pistamax = 0;  //resetea esta variable de estado por prepunta
                  //document.getElementById("pista").innerHTML=respuesta_oculta;

                  	                                 
            }
	  }); 
	}

	function mostrarPregunta() {
	  pregunta = Questions[qnumber];
      respuesta=Answers[qnumber];
      idpregunta = qnumber + 1;
      pistamax = 0;  //resetea esta variable de estado por prepunta
      document.getElementById("pista").innerHTML="";
      document.getElementById("pista2").disabled = true;
      document.getElementById("pista3").disabled = true;
      document.getElementById("continuar").style.display= "none";          
      document.getElementById("idpregunta").innerHTML = "Pregunta " + idpregunta + ":";
	  document.getElementById("pregunta").innerHTML = pregunta;
      respuesta_normalizada = normalize(respuesta);
      respuesta_oculta = respuesta_normalizada.toLowerCase().replace(/[a-z,0-9]/gi,'_');
      //document.getElementById("pista").innerHTML=respuesta_oculta;
      document.getElementById("validar").disabled = false;

      document.getElementById("feedback_msg").innerHTML="";
      document.getElementById("icofeed").style.background="";
      document.getElementsByName("useranswer")[0].value="";

	}

   function mostrarPista(cadena,separador,numpista) {
      var stringDeCadenas = cadena.split(separador);
      var Articulaciones = new Array;
      Articulaciones=["ya", "la", "las", "su", "da", "de", "del", "di", "la", "el", "al", "con", "y", "para", "en", "desde", "por", "los", "en", "días", "dias", "a", "un", "una", "dos", "tres", "ante", "in", "day", "for", "the", "and", "by"];
      var respuestaporpalabra="";   
      var respuestahidden = ""; 
      var contador=0;

      switch(numpista){
        case 1:
          for (var i=0; i < stringDeCadenas.length; i++) {
             respuestaporpalabra = stringDeCadenas[i];
             contador=0;
             for (var j=0; j < Articulaciones.length; j++) {      
                if(respuestaporpalabra != Articulaciones[j])
                        contador++;
             }
             if(contador >= Articulaciones.length)
                   respuestahidden += normalize(respuestaporpalabra).replace(/[a-zA-Z0-9]/gi,'_') + " ";
             else 
                   respuestahidden += respuestaporpalabra + " ";      
          }
          break;

        case 2:
          for (var i=0; i < stringDeCadenas.length; i++) {
             respuestaporpalabra = stringDeCadenas[i];
             respuestasoloprimeraletra = respuestaporpalabra.slice(0,1);
             respuestasinprimeraletra = respuestaporpalabra.slice(1);
             //alert(respuestaporpalabra + ", " + respuestasoloprimeraletra +  ", " +  respuestasinprimeraletra );         
             respuestahidden += respuestasoloprimeraletra + normalize(respuestasinprimeraletra).replace(/[a-zA-Z0-9]/gi,'_') + " ";             
          }
          break;

        case 3:
          var aleatindex;
          for (var i=0; i < stringDeCadenas.length; i++) {
             respuestaporpalabra = stringDeCadenas[i];
             aleatindex = Math.floor(Math.random()*respuestaporpalabra.length);
             respuestaprimeraparte = respuestaporpalabra.slice(0,aleatindex);
             respuestasegundaparte = respuestaporpalabra.slice(aleatindex, aleatindex+1);
             respuestaterceraparte = respuestaporpalabra.slice(aleatindex+1);
             //alert(respuestaporpalabra + ", " + respuestasoloprimeraletra +  ", " +  respuestasinprimeraletra );         
             respuestahidden += normalize(respuestaprimeraparte).replace(/[a-zA-Z0-9]/gi,'_') + respuestasegundaparte  + normalize(respuestaterceraparte).replace(/[a-zA-Z0-9]/gi,'_') + " ";             
          }
          break;

      }
      return respuestahidden;
   } 


   function endQuiz() {
         quizFinalizado = true;
         inforesumen = "";
         document.getElementById("ajustes").style.display= "none";
         document.getElementById("scorepanel").style.display= "none"; 
         document.getElementById("quiz").style.display= "none";
         document.getElementById("ahorcado").style.display= "none";
         document.getElementById("pfinal").style.display= "block";

         if($('input:checkbox[name=ahorcadofin]:checked').val() === 'ahorcado')
              cuandofinjuego =  $('input:checkbox[name=ahorcadofin]:checked').val();
        else
              cuandofinjuego = "Todas las preguntas sean respondidas";

         document.getElementById("final_score").innerHTML=puntuacion+"<br>puntos";
       
         inforesumen+="Cuestionario (Quiz): "+$("#fuente").val() + "<br>";
         inforesumen+="Categoría: "+$("#fuente").val() + "<br>";
         inforesumen+="Aciertos: "+aciertos+"<br>Fallos: "+fallos+"<br>";
         inforesumen+="Fin de Juego cuando: "+cuandofinjuego+"<br>Fallos: "+fallos+"<br>";
         inforesumen+="Aciertos: "+aciertos+"<br>Fallos: "+fallos+"<br>";
         

         document.getElementById("resultadofinal").innerHTML= inforesumen;
         return false;        
   }

   function mostrarScorePanel(){
   		var resumenajustes = "";
   		document.getElementById("ajustes").style.display= "none";
     	document.getElementById("scorepanel").style.display= "block";   
     	resumenajustes += "Bienvenido " + document.getElementById("nombre").value + " al Quiz-Aventura <br><br><strong> Preferencias del Juego:</strong> <br> Origen de Preguntas: " + $("#fuente").val() +  "<br> categoria: " + $("#categoria").val() + "<br> Número de Preguntas: " + $("#num_preguntas").val() + "<br>";  
   	
        if($('input:checkbox[name=ahorcadofin]:checked').val() === 'ahorcado')
   				resumenajustes += "Finalización del Juego cuando: " +  $('input:checkbox[name=ahorcadofin]:checked').val() + " <br>";
        else
          resumenajustes += "Finalización del Juego cuando: " +  "Todas las preguntas sean respondidas<br>";
        
        resumenajustes += "Puntuación por pregunta acertada: " +  $('input:radio[name=puntuacion]:checked').val() + " <br>";
                         
        document.getElementById("resumenajustes").innerHTML = resumenajustes;

        document.getElementById("score").innerHTML = 0;

        document.getElementById("resumenscore").innerHTML = "<br><strong> Detalles de Puntuación obtenida:</strong>";
   }


   
	//invocamos esta función cuando hacemos click al elemento de id="saludo"
	$("#fuente").change(function(e){
			getCategorias();		
	});	

   $("#categoria").change(function(e){
         getNumPreguntas();     
   });   

	$("#nombre").focusout(function(e){
		alert("Bienvenido " + document.getElementById("nombre").value + " al Quiz-Aventura");
	});

   $("#num_preguntas").change(function(e){
         document.getElementById("valorpreg").innerHTML=document.getElementById("num_preguntas").value;   
   }); 

   $("#botonplay").click(function(e){
     Init();
     mostrarScorePanel();
     getPreguntas(); 
     
     return false;
   });

   $("#irajustes").click(function(e){
     alert("ir a ajustes");
     resetAjustes();    
     return false;
   });

   $("#pista1").click(function(e){
     var frase_respuesta =Answers[qnumber];
     var primerapista = "";
     if(pistamax < 1) {//Este control permitirá no repetir
        primerapista = mostrarPista(frase_respuesta, " ", 1);    
        pistamax = 1;   //Este control indicará cuál es la pista max mostrada para efectos de puntuación
        document.getElementById("pista").innerHTML=primerapista;
        document.getElementById("pista2").disabled = false;
      }
     return false;
   });
   
   $("#pista2").click(function(e){   
     var frase_respuesta =Answers[qnumber];
     var segundapista = "";
     if(pistamax < 2){
        segundapista = mostrarPista(frase_respuesta, " ", 2);
        pistamax = 2;
        document.getElementById("pista").innerHTML=segundapista;
        document.getElementById("pista3").disabled = false;
      }
     return false;
   });

   $("#subirxml").click(function(e){   
     $.get('modal2.html', function(data){
          modal.open({content: data});            
      });
      e.preventDefault();
     return false;
   });

   

   $("#pista3").click(function(e){   
     var frase_respuesta =Answers[qnumber];
     var tercerapista = "";
     if(pistamax <3){
       tercerapista = mostrarPista(frase_respuesta, " ", 3);
       pistamax = 3;
       document.getElementById("pista").innerHTML=tercerapista;
      }
     return false;
   });

   $("#validar").click(function(e){ 
   	  var puntos = 0;
   	  var multiplicador = 1;
      var respuesta = Answers[qnumber];
      var respuesta_user = document.getElementsByName("useranswer")[0].value;
      var respuesta_user_normalizada = normalize(respuesta_user).toLowerCase();
      var respuesta_normalizada = normalize(respuesta).toLowerCase();
      //alert(respuesta_normalizada + "---" + respuesta_user_normalizada);
      if(respuesta_user_normalizada==respuesta_normalizada){
         aciertos++; 

         switch(pistamax){
         	case 1:
         		multiplicador = 0.75;
         		break;
         	case 2: 
         		multiplicador = 0.5;
         		break;
         	case 3:
         		multiplicador = 0.25;
         		break;
         	default:
         		multiplicador = 1;
         }

         puntos = Number($('input:radio[name=puntuacion]:checked').val()) * multiplicador;

         puntuacion += puntos;
         document.getElementById("score").innerHTML = puntuacion;

         document.getElementById("feedback_msg").innerHTML="Enhorabuena, has acertado la pregunta";
         document.getElementById("icofeed").style.background="url('images/quizbg.png') 0px -400px";
         document.getElementById("validar").disabled = true;
         

      } 
      else{
         fallos++;         
         document.getElementById("feedback_msg").innerHTML=respuesta;
         document.getElementById("icofeed").style.background="url('images/quizbg.png')-76px -400px";
         document.getElementById("validar").disabled = true;
         context.font = "1em San-serif,Arial";

         switch(fallos){
            case 1:
               context.drawImage(hangmancabeza, 5, 40);  
               context.clearRect(0,0,100,25);             
               context.fillStyle ="rgb(25,25,25)";
               context.fillText("¡Cuidado!:",7,15);  
               break;
            case 2:
               context.drawImage(hangmancuerpo, 5, 40);
               context.clearRect(0,0,100,25);             
               context.fillStyle ="rgb(25,25,25)";
               context.fillText("¡Peligro!:",7,15);  
               break;
            case 3:
               context.drawImage(hangmanbrazos, 5, 40);
               context.clearRect(0,0,100,25);             
               context.fillStyle ="rgb(255,25,25)";
               context.fillText("¡Entre la vida y ...!:",7,15);
               break;
            case 4:
               context.drawImage(hangmanpiernas, 5, 40);
               context.clearRect(0,0,100,25);             
               context.fillStyle ="rgb(255,25,25)";
               context.fillText("¡Ahorcado!:",7,15);
               if(finQuizSiAhorcado)
                  quizFinalizado = true;

               break;

         }
      }
      if(quizFinalizado){
         endQuiz();
         document.getElementById("continuar").style.display= "none";
      }
      else
         document.getElementById("continuar").style.display= "block";
      
      return false;
     
   });

   $("#continuar").click(function(e){ 
     npreguntas = $("#num_preguntas").val();
     qnumber++;
     if(qnumber >= npreguntas){
         endQuiz();

     }
     else{
         
         mostrarPregunta();
     }
     return false;
   });

   $("#pf_grabar").click(function(e){
    window.open('instrucciones_modal.html','_blank');
    
  });


  $("#pf_menu").click(function(e){
     window.open('instrucciones_modal.html','_blank');
  
  });

  $("#pf_historico").click(function(e){
     window.open('instrucciones_modal.html','_blank');
    
  });
   

   

   var normalize = (function() {
      var from = "ÃÀÁÄÂÈÉËÊÌÍÏÎÒÓÖÔÙÚÜÛãàáäâèéëêìíïîòóöôùúüûÑñÇç";
      var to   = "AAAAAEEEEIIIIOOOOUUUUaaaaaeeeeiiiioooouuuunncc";
      var mapping = {};
       
        for(var i = 0, j = from.length; i < j; i++ )
            mapping[ from.charAt( i ) ] = to.charAt( i );
       
        return function( str ) {
            var ret = [];
            for( var i = 0, j = str.length; i < j; i++ ) {
           var c = str.charAt( i );
           if( mapping.hasOwnProperty( str.charAt( i ) ) )
               ret.push( mapping[ c ] );
           else
               ret.push( c );
            }      
            return ret.join( '' );
        }
       
   })();







});














