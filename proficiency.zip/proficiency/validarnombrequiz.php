<?php

require_once(dirname(dirname(dirname(__FILE__))).'/config.php');


$nombrequiz = $_POST['nombrequiz'];
$tablaquiz = $_POST['nombretablaquiz'];


/** El nombre de tu base de datos */
define('DB_NAME', $CFG->dbname);

/** Tu nombre de usuario de MySQL */
define('DB_USER', $CFG->dbuser);

/** Tu contraseña de MySQL */
define('DB_PASSWORD', $CFG->dbpass);

/** Host de MySQL (es muy probable que no necesites cambiarlo) */
define('DB_HOST', $CFG->dbhost);

/** Codificación de caracteres para la base de datos. */
define('DB_CHARSET', 'utf8');

echo 1;


?>
