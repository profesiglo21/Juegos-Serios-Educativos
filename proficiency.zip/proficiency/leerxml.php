<?php

require_once(dirname(dirname(dirname(__FILE__))).'/config.php');

global $USER;
$nombrequiz = $_POST['nombrequiz'];
$descripcion = $_POST['descripcion'];


/** El nombre de tu base de datos */
define('DB_NAME', $CFG->dbname);

/** Tu nombre de usuario de MySQL */
define('DB_USER', $CFG->dbuser);

/** Tu contraseña de MySQL */
define('DB_PASSWORD', $CFG->dbpass);

/** Host de MySQL (es muy probable que no necesites cambiarlo) */
define('DB_HOST', $CFG->dbhost);

/** Codificación de caracteres para la base de datos. */
define('DB_CHARSET', 'utf8');



function conectarBD()
{
	/* create a connection object which is not connected */
	$mysqli = mysqli_init();

	/* set connection options */
	$mysqli->options(MYSQLI_OPT_LOCAL_INFILE, true);

	/* connect to server */
	$mysqli->real_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
	$mysqli->set_charset(DB_CHARSET);
		
	/* check connection */
	if (mysqli_connect_errno()) {
			printf("Conexión fallida: %s\n", mysqli_connect_error());
			exit();
	}		
	return $mysqli;
}



$dir_subida = $CFG->dirroot . '/mod/proficiency/uploads/';
$fichero_subido = $dir_subida . basename($_FILES['file']['name']);


if (!move_uploaded_file($_FILES['file']['tmp_name'], $fichero_subido))
  	echo "¡Posible ataque de subida de ficheros!\n";


function eliminarEspacios($texto){
	return trim($texto," \t\n\0\x0B");

}

$conexion = conectarBD();

$dom = new DOMDocument();
$data = file_get_contents($fichero_subido);
$dom->loadXML($data);

$addquiz = "INSERT INTO " . $CFG->prefix . "proficiency_quizzes(userid, name, intro, timecreated) values (". $USER->id .", '".$nombrequiz."', '".$descripcion."', ". time().")";
 			
$resultado = $conexion->query($addquiz);
if (!$resultado) 
    return false;

$newquizid = $conexion->insert_id;

$preguntas = $dom->getElementsByTagName('preguntas')->item(0);

foreach($preguntas->getElementsByTagName('pregunta') as $pregunta){
		$preguntatexto = $pregunta->getElementsByTagName('preguntatexto')->item(0);
		$respuesta = $pregunta->getElementsByTagName('respuesta')->item(0);
		$categoria = $pregunta->getElementsByTagName('categoria')->item(0);

		$insertsql = "INSERT INTO  " . $CFG->prefix . "proficiency_questions(quizid, pregunta, respuesta, categoria) VALUES (".$newquizid.",'".eliminarEspacios($preguntatexto->nodeValue)."', '". eliminarEspacios($respuesta->nodeValue) . "', '". eliminarEspacios($categoria->nodeValue) ."')";	
        if ($conexion->query($insertsql) !== TRUE) {
     		echo "Error creating table: " . $conexion->error;
		}   		
		
}



$conexion->close();
?>
