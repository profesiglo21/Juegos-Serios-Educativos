<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Prints a particular instance of proficiency
 *
 * You can have a rather longer description of the file as well,
 * if you like, and it can span multiple lines.
 *
 * @package    mod_proficiency
 * @copyright  2011 Your Name
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

/// (Replace proficiency with the name of your module and remove this line)

require_once(dirname(dirname(dirname(__FILE__))).'/config.php');
require_once(dirname(__FILE__).'/lib.php');

$id = optional_param('id', 0, PARAM_INT); // course_module ID, or
$n  = optional_param('n', 0, PARAM_INT);  // proficiency instance ID - it should be named as the first character of the module

if ($id) {
    $cm         = get_coursemodule_from_id('proficiency', $id, 0, false, MUST_EXIST);
    $course     = $DB->get_record('course', array('id' => $cm->course), '*', MUST_EXIST);
    $proficiency  = $DB->get_record('proficiency', array('id' => $cm->instance), '*', MUST_EXIST);
} elseif ($n) {
    $proficiency  = $DB->get_record('proficiency', array('id' => $n), '*', MUST_EXIST);
    $course     = $DB->get_record('course', array('id' => $proficiency->course), '*', MUST_EXIST);
    $cm         = get_coursemodule_from_instance('proficiency', $proficiency->id, $course->id, false, MUST_EXIST);
} else {
    error('You must specify a course_module ID or an instance ID');
}

require_login($course, true, $cm);
$context = context_module::instance($cm->id);
add_to_log($course->id, 'proficiency', 'view', "view.php?id={$cm->id}", $proficiency->name, $cm->id);

/// Print the page header
$PAGE->set_url('/mod/proficiency/view.php', array('id' => $cm->id));
$PAGE->set_title(format_string($proficiency->name));
$PAGE->requires->css('/mod/proficiency/css/quiz.css', true);
$PAGE->requires->css('/mod/proficiency/css/modal.css', true);

//inclusion del javascript para las funciones
$PAGE->requires->js('/mod/proficiency/js/jquery.js', true);
$PAGE->requires->js('/mod/proficiency/js/quiz.js', true);
$PAGE->requires->js('/mod/proficiency/js/modal.js', true);

$PAGE->set_heading(format_string($course->fullname));
$PAGE->set_context($context);

// other things you may want to set - remove if not needed
$PAGE->set_cacheable(false);
//$PAGE->set_focuscontrol('some-html-id');
//$PAGE->add_body_class('proficiency-'.$somevar);

// Output starts here
echo $OUTPUT->header();
if ($proficiency->intro) { // Conditions to show the intro can change to look for own settings or whatever
    echo $OUTPUT->box(format_module_intro('proficiency', $proficiency, $cm->id), 'generalbox mod_introbox', 'proficiencyintro');
}

// Replace the following lines with you own code
echo $OUTPUT->heading('
    <div id="contenedor">
            <header>
                    <nav></nav>
            </header>
            <div id="contenido">
                <div id="scorepanel">
                    <img id="logo" src="images/logo.png" width="90px" alt="logo del Juego Proficiency"/>
                    <legend id="irajustes">Ir a Ajuste del Juego</legend><br>
                    <span id="resumenajustes"></span>
                    <span id="score"></span> puntos
                    <span id="resumenscore"></span>
                </div>               
                <div id="pfinal">
                    <div>
                        <span id="resultadofinal">                            
                        </span>
                        <span id="final_score"></span>
                        <span id="savescore"><label>Guardar</label><input id="pf_grabar" type="image" src="images/boton_red_small.png" alt="Grabar jugada" target="_blank"></span>
                        <span id="menu"><label>Menú Principal</label><input id="pf_menu" type="image" src="images/boton_blue_small.png" alt="Volver a menú principal"></span>
                        <span id="play"><label>Histórico</label><input id="pf_historico" type="image" src="images/boton_green_small.png" alt="Ver el histórico de puntuaciones"></span>                  
                    </div>
                </div>               
                <div id="ajustes">                       
                        <img src="images/logo.png" width="100px" alt="logo del Juego Proficiency"/><br><br><br><br>
                        <fieldset id="config"> 
                        <br><legend>Ajuste del Juego</legend>
                        <label for="nombre">Introduzca su Nombre:</label><br>
                        <input type="text" id="nombre" name="nombre" maxlength="12"><br>
                        <label for="fuente">Seleccione la Fuente de las Preguntas:</label><br>
                        <select name="fuente" id="fuente">                            
                        </select><br>
                        <label for="categoria">Seleccione la categoría:</label><br>
                        <select name="categoria" id="categoria">
                            <option value="null">-- Ninguna categoría seleccionada --</option>          
                        </select><br>
                        <fieldset id="fpunt">
                        <label for="puntuacion">Puntuación por Pregunta</label><br>
                            <input type="radio" name="puntuacion" value="100">100<br>
                            <input type="radio" name="puntuacion" value="200">200<br>
                            <input type="radio" name="puntuacion" value="500">500<br>
                        </fieldset>
                        <label for="num_preguntas">Usted ha elegido (deslice la barra para seleccionar el nº de preguntas):</label><br>
                        <span id="valorpreg">-</span> preguntas
                        <input id="num_preguntas" type="range" min="1" max="100" step="1" disabled> 
                        (nº Max. <label id="maxpreguntas"></label>)<br><br>
                        <input id="ahorcadofin" type="checkbox" name="ahorcadofin" value="ahorcado"> Finalizar el juego cuando esté ahorcado.
                        </fieldset> 
                        <div id="controles">                            
                            <input id="botonplay" type="image" src="images/empezar_juego.png" alt="Iniciar Juego" title="Iniciar Juego" disabled="true">
                        </div>                       
                </div>
                <div id="quiz">
                    <div id="preguntas">
                        <span id="idpregunta"></span><span id="pregunta"></span>
                        <span id="respuesta">
                            <input type="text" name="useranswer" placeholder="Responda a la pregunta">
                            <span><input id="validar" type="image" src="images/validar.png" alt="validar" title="Validar Pregunta"></span>
                        </span>
                        <span id="tip">
                            <input id="pista1" type="image" src="images/pistagreen.png" alt="pista 1 - penaliza con el 25% de la puntuación" title="pista 1 - penaliza con el 25% de la puntuación">
                            <input id="pista2" type="image" src="images/pistayellow.png" alt="pista 2 - penaliza con el 50% de la puntuación" title="pista 2 - penaliza con el 50% de la puntuación">
                            <input id="pista3" type="image" src="images/pistared.png" alt="pista 3 - penaliza con el 75% de la puntuación" title="pista 3 - penaliza con el 75% de la puntuación">
                            <span id="pista"></span></span>
                        </span>
                        <span id="feedback">
                            <span id="feedback_msg"></span>
                            <span id="iconfeed"><img id="icofeed" src="images/img_trans.gif" align="middle"></span>                                                   
                        </span>
                        <span id="continuar">Haz clic para continuar</span>                            
                    </div>
                </div>
                <div id="penalizaciones">
                    <canvas id="ahorcado" width="100" height="400"></canvas>
                </div>
                 <footer></footer>
            </div>           
        </div>');




// Finish the page
echo $OUTPUT->footer();
