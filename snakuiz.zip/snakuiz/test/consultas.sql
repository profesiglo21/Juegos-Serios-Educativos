SELECT id, pregunta as quest, respuesta as answer FROM trivial ORDER BY RAND() LIMIT 4;
SELECT q.id, q.questiontext FROM mdl_question AS q, mdl_qtype_shortanswer_options AS s WHERE q.id = s.questionid AND q.category = 23 ORDER BY RAND() LIMIT 4;
SELECT q.id, q.questiontext FROM mdl_question AS q, mdl_question_truefalse AS t WHERE q.id = t.question AND q.category =23 ORDER BY RAND() LIMIT 4;
