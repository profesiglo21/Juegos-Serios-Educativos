<?php
 
      $buscar = $_POST['b'];
      //$buscar = "salim";
      $contar = 0;
	  

       
      if(isset($buscar)) {
	  		$arrayPalabras = explode(',',$buscar);
			for ($i = 0; $i <= count($arrayPalabras); $i++) {
    			buscar($arrayPalabras[$i]);
			}
			if (count($arrayPalabras) == $contar)
				echo "1";
			else 
				echo "0";          
      }
       
      function buscar($b) {
            $con = mysql_connect('localhost','root', '123456');
            mysql_select_db('test', $con);
       
            $sql = mysql_query("SELECT * FROM mydiccionario_es WHERE palabra = '".$b."'",$con);
             
            $existe = mysql_num_rows($sql);
             
            if($existe > 0){
                  $contar++;
            }
      }
       
?>
