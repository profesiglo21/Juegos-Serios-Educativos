<?php
/** El nombre de tu base de datos */
define('DB_NAME', 'test');

/** Tu nombre de usuario de MySQL */
define('DB_USER', 'root');

/** Tu contraseña de MySQL */
define('DB_PASSWORD', '');

/** Host de MySQL (es muy probable que no necesites cambiarlo) */
define('DB_HOST', 'localhost');

/** Codificación de caracteres para la base de datos. */
define('DB_CHARSET', 'utf8');

function conectarBD()
{
	/* create a connection object which is not connected */
	$mysqli = mysqli_init();

	/* set connection options */
	$mysqli->options(MYSQLI_OPT_LOCAL_INFILE, true);

	/* connect to server */
	$mysqli->real_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
	$mysqli->set_charset(DB_CHARSET);
		
	/* check connection */
	if (mysqli_connect_errno()) {
			printf("Conexión fallida: %s\n", mysqli_connect_error());
			exit();
	}		
	return $mysqli;
}

function eliminarEspacios($texto){
	return trim($texto," \t\n\0\x0B");

}

$conexion = conectarBD();

$droptable = "DROP TABLE IF EXISTS Trivial";

if ($conexion->query($droptable) !== TRUE) {
     echo "Error creating table: " . $conexion->error;
}

$createsql = "CREATE TABLE Trivial (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
pregunta VARCHAR(255) NOT NULL,
respuesta VARCHAR(255) NOT NULL,
categoria VARCHAR(10) NOT NULL
)";


if ($conexion->query($createsql) !== TRUE) {
     echo "Error creating table: " . $conexion->error;
}

$dom = new DOMDocument();
$data = file_get_contents('trivial.xml');
$dom->loadXML($data);

$preguntas = $dom->getElementsByTagName('preguntas')->item(0);

foreach($preguntas->getElementsByTagName('pregunta') as $pregunta){
		$preguntatexto = $pregunta->getElementsByTagName('preguntatexto')->item(0);
		$respuesta = $pregunta->getElementsByTagName('respuesta')->item(0);
		$categoria = $pregunta->getElementsByTagName('categoria')->item(0);

		$insertsql = "INSERT INTO Trivial (pregunta, respuesta, categoria) VALUES ('".eliminarEspacios($preguntatexto->nodeValue)."', '". eliminarEspacios($respuesta->nodeValue) . "', '". eliminarEspacios($categoria->nodeValue) ."')";	
        if ($conexion->query($insertsql) !== TRUE) {
     		echo "Error creating table: " . $conexion->error;
		}   		
		
}

$conexion->close();
?>