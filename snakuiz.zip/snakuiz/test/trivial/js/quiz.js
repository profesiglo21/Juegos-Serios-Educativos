$(document).ready(function() 
{ 		
	//estructura de tipo array para recoger los datos que vienen del .php
	var Questions = new Array;
	var Answers = new Array;
	var Categorias = new Array;
   

	var qnumber = 0;
	var aciertos = 0;
	var fallos = 0;
	var quizFinalizado = false;
   var finQuizSiAhorcado = false;
   
   //imágenes hangman 
   var hangmancuerda = new Image();
   var hangmancabeza = new Image();   
   var hangmancuerpo = new Image();
   var hangmanbrazos = new Image();
   var hangmanpiernas = new Image();
   var hangmanentero = new Image();

   //ahorcado canvas
   var qcanvas = $("#ahorcado")[0];
   var context = qcanvas.getContext("2d");

   hangmancuerda.onload = function() {
         context.drawImage(hangmancuerda, 5, 40);      
   };

   hangmancuerda.src = 'images/hangman/cuerda.png';
   hangmancabeza.src = 'images/hangman/cabeza.png';    
   hangmancuerpo.src = 'images/hangman/cuerpo.png'; 
   hangmanbrazos.src = 'images/hangman/brazos.png';
   hangmanpiernas.src = 'images/hangman/piernas.png';
   hangmanentero.src = 'images/hangman/entero.png';

   
    

   function Init(){
   	document.getElementById("quiz").style.display="block";
      document.getElementById("penalizaciones").style.display="block";
      document.getElementById("continuar").style.display= "none";
      
      var $radios = $('input:checkbox[name=ahorcadofin]');
      if($radios.is(':checked') === true) {
         finQuizSiAhorcado = true;
      }
   
      context.textBaseline = "middle";
      context.font = "1.2em San-serif,Arial";
      context.fillStyle ="rgb(25,25,25)";
      context.fillText("¡En Peligro!:",10,15);      
      context.fillStyle ="rgb(63,123,164)";      
      context.fillText(document.getElementById("nombre").value,10,30);
         
   }

        


   function resetAjustes(){

         $('#categoria').empty();
         $('#categoria').append('<option value="null">-- Ninguna categoría seleccionada --</option>'); 
        
         $('input:radio[name=puntuacion]').removeAttr('checked');
         document.getElementById("maxpreguntas").innerHTML = 0;
         document.getElementById("num_preguntas").disabled=true;
         document.getElementById("valorpreg").innerHTML = 0;

   }


   function getCategorias(){
        fuente = $("#fuente").val();
      	$.ajax({
            type: "POST",
            url: "obtenercategorias.php",
            data: "fuen="+fuente,
            dataType: "json",
            error: function(){
                 alert("error petición ajax");
                 resetAjustes();
            },
            success: function(data){
              //recuperar información de fichero .php que envia lista de valores
              Categorias = data;

              $('#categoria').empty();
         	  $('#categoria').append('<option value="null">-- Ninguna categoría seleccionada --</option>');	

         	  if(fuente == 'trivial'){
            	  $.each(Categorias, function(key,value){
            	  		switch(value){
            	  			case 'G':
            	  					descripcion = 'Geografía';
            	  					break;   	  					
            	  			case 'E':
            	  					descripcion = 'Entretenimiento';
            	  					break;   	  					
            	  			case 'H':
            	  					descripcion = 'Historia';
            	  					break;
            	  			case 'AL':
            	  					descripcion = 'Arte y Literatura';
            	  					break;
            	  			case 'C':
            	  					descripcion = 'Ciencia';
            	  					break;
            	  		}

            	  		$('#categoria').append($('<option>',{
            	  		    value:value,
            	  			text:descripcion
            	      }));  	   
            	   });

                 $('#categoria').append('<option value="TODAS">Todas la categorías</option>');   

                 $(function() {
                     var $radios = $('input:radio[name=puntuacion]');
                     if($radios.is(':checked') === false) {
                          $radios.filter('[value=200]').prop('checked', true);
                     }
                  }); 
               }
            }
	  });   	 
   }

   
   function getNumPreguntas() {
    //obtenemos los datos introducido en el campo del formulario
   fuente = $("#fuente").val();
   categoria = $("#categoria").val(); 
                                                            
   //hace la búsqueda
   $.ajax({
            type: "POST",
            url: "obtenernumpreguntas.php",
            data: "fuen="+fuente+"&cat="+categoria,
            dataType: "html",
            error: function(){
                  alert("error petición ajax");
                  resetAjustes();
            },
            success: function(data){
                 //recuperar información de fichero .php que envia lista de valores
             
                  document.getElementById("maxpreguntas").innerHTML = data;
                  
                  if(Number(data)> 0){
                       document.getElementById("num_preguntas").setAttribute("max", data);
                       document.getElementById("num_preguntas").setAttribute("min", 1);
                       document.getElementById("num_preguntas").disabled=false;
                       document.getElementById("botonplay").disabled = false;
                       document.getElementById("valorpreg").innerHTML =document.getElementById("num_preguntas").value;
                  }
                  else
                     document.getElementById("num_preguntas").disabled=true;

                                                        
            }
     }); 
   }     
	
   function getPreguntas() {
    //obtenemos los datos introducido en el campo del formulario
	fuente = $("#fuente").val();
	categoria = $("#categoria").val();
	npreguntas = $("#num_preguntas").val();

	//alert("fuen="+fuente+"&cat="+categoria+"&npreg="+npreguntas);                                                     
	//hace la búsqueda
	$.ajax({
            type: "POST",
            url: "obtenerpreguntas.php",
            data: "fuen="+fuente+"&cat="+categoria+"&npreg="+npreguntas,
            dataType: "json",
            error: function(){
                  alert("error petición ajax (obtenerpreguntas.php)");
            	  
            },
            success: function(data){
            	  //recuperar información de fichero .php que envia lista de valores
                  Questions = data[0];
                  Answers = data[1];
                  idpregunta = qnumber + 1;
                  pregunta = Questions[qnumber];
                  document.getElementById("idpregunta").innerHTML = "Pregunta " + idpregunta + ":";
		            document.getElementById("pregunta").innerHTML = pregunta;
                  respuesta=Answers[qnumber];
                  respuesta_normalizada = normalize(respuesta);
                  respuesta_oculta = respuesta_normalizada.toLowerCase().replace(/[a-z,0-9]/gi,'_');
                  document.getElementById("pista").innerHTML=respuesta_oculta;

                  	                                 
            }
	  }); 
	}

	function mostrarPregunta() {
		pregunta = Questions[qnumber];
      respuesta=Answers[qnumber];
      idpregunta = qnumber + 1;
      document.getElementById("continuar").style.display= "none";          
      document.getElementById("idpregunta").innerHTML = "Pregunta " + idpregunta + ":";
		document.getElementById("pregunta").innerHTML = pregunta;
      respuesta_normalizada = normalize(respuesta);
      respuesta_oculta = respuesta_normalizada.toLowerCase().replace(/[a-z,0-9]/gi,'_');
      document.getElementById("pista").innerHTML=respuesta_oculta;
      document.getElementById("validar").disabled = false;

      document.getElementById("feedback_msg").innerHTML="";
      document.getElementById("icofeed").style.background="";
      document.getElementsByName("useranswer")[0].value="";

	}

   function mostrarPista(cadena,separador) {
      var stringDeCadenas = cadena.split(separador);
      var Articulaciones = new Array;
      Articulaciones=["ya", "la", "las", "su", "da", "de", "del", "di", "la", "el", "al", "con", "y", "para", "en", "desde", "por", "los", "en", "días", "dias", "a", "un", "una", "dos", "tres", "ante", "in", "day", "for", "the", "and", "by"];
      var respuestaporpalabra="";   
      var respuestahidden = ""; 
      var contador=0;

      for (var i=0; i < stringDeCadenas.length; i++) {
         respuestaporpalabra = stringDeCadenas[i].toLowerCase();
         contador=0;
         for (var j=0; j < Articulaciones.length; j++) {      
            if(respuestaporpalabra != Articulaciones[j])
                    contador++;
         }
         if(contador >= Articulaciones.length)
               respuestahidden += respuestaporpalabra.replace(/[a-z0-9]/gi,'_') + " ";
         else 
               respuestahidden += respuestaporpalabra + " ";      
      }
      return respuestahidden;
   }

   function endQuiz() {
         quizFinalizado = true;
         alert("Fin del Juego: Aciertos: " + aciertos + " Fallos: " + fallos);
   }


   
	//invocamos esta función cuando hacemos click al elemento de id="saludo"
	$("#fuente").change(function(e){
			getCategorias();		
	});	

   $("#categoria").change(function(e){
         getNumPreguntas();     
   });   

	$("#nombre").focusout(function(e){
		alert("Bienvenido " + document.getElementById("nombre").value + " al Quiz-Aventura");
	});

   $("#num_preguntas").change(function(e){
         document.getElementById("valorpreg").innerHTML=document.getElementById("num_preguntas").value;   
   }); 

   $("#botonplay").click(function(e){
     Init();
     getPreguntas();        
     return false;
   });

   $("#pista1").click(function(e){
     var frase_respuesta =Answers[qnumber];
     var primerapista = mostrarPista(frase_respuesta, " ");
     document.getElementById("pista").innerHTML=primerapista;
     return false;
   });

   $("#validar").click(function(e){ 
      var respuesta = Answers[qnumber];
      var respuesta_user = document.getElementsByName("useranswer")[0].value;
      var respuesta_user_normalizada = normalize(respuesta_user).toLowerCase();
      var respuesta_normalizada = normalize(respuesta).toLowerCase();
      //alert(respuesta_normalizada + "---" + respuesta_user_normalizada);
      if(respuesta_user_normalizada==respuesta_normalizada){
         aciertos++;         
         document.getElementById("feedback_msg").innerHTML="Enhorabuena, has acertado la pregunta";
         document.getElementById("icofeed").style.background="url('../images/quizbg.png') 0px -400px";
         document.getElementById("validar").disabled = true;

      } 
      else{
         fallos++;         
         document.getElementById("feedback_msg").innerHTML=respuesta;
         document.getElementById("icofeed").style.background="url('../images/quizbg.png')-76px -400px";
         document.getElementById("validar").disabled = true;

         switch(fallos){
            case 1:
               context.drawImage(hangmancabeza, 5, 40);
               break;
            case 2:
               context.drawImage(hangmancuerpo, 5, 40);
               break;
            case 3:
               context.drawImage(hangmanbrazos, 5, 40);
               break;
            case 4:
               context.drawImage(hangmanpiernas, 5, 40);
               if(finQuizSiAhorcado)
                  quizFinalizado = true;

               break;

         }
      }
      if(quizFinalizado){
         endQuiz();
         document.getElementById("continuar").style.display= "none";
      }
      else
         document.getElementById("continuar").style.display= "block";
      
      return false;
     
   });

   $("#continuar").click(function(e){ 
     npreguntas = $("#num_preguntas").val();
     qnumber++;
     if(qnumber >= npreguntas){
         endQuiz();

     }
     else{
         mostrarPregunta();
     }
     return false;
   });

   

   var normalize = (function() {
      var from = "ÃÀÁÄÂÈÉËÊÌÍÏÎÒÓÖÔÙÚÜÛãàáäâèéëêìíïîòóöôùúüûÑñÇç";
      var to   = "AAAAAEEEEIIIIOOOOUUUUaaaaaeeeeiiiioooouuuunncc";
      var mapping = {};
       
        for(var i = 0, j = from.length; i < j; i++ )
            mapping[ from.charAt( i ) ] = to.charAt( i );
       
        return function( str ) {
            var ret = [];
            for( var i = 0, j = str.length; i < j; i++ ) {
           var c = str.charAt( i );
           if( mapping.hasOwnProperty( str.charAt( i ) ) )
               ret.push( mapping[ c ] );
           else
               ret.push( c );
            }      
            return ret.join( '' );
        }
       
   })();







});














