$(document).ready(function() 
{ 	
	//estructura de tipo array para recoger los datos que vienen del .php
	var lista_datos = new array;
	var lista_datos2 = new array;

	//hacemos focus al campo de búsqueda
	//$("#busqueda").focus();

	
	
	
   function getPreguntas() {

    //obtenemos los datos introducido en el campo del formulario
	nombre = $("#nombre").val();
	fuente = $("#fuente").val();
	categoria = $("#categoria").val();
	puntuacion = $("#puntuacion").val();
	npreguntas = $("#num_preguntas").val();
	                                                         
	//hace la búsqueda
	$.ajax({
            type: "POST",
            url: "obtenerpreguntas.php",
            data: "nom="+nombre+"&fuen="+fuente+"&cat="+categoria+"&punt="+puntuacion+"&npreg"+npreguntas,
            dataType: "json",
            beforeSend: function(){
                  //imagen de carga mientras está procesando la respuesta
                  //$("#relojimage").html("<p align='center'><img src='reloj.gif'/></p>");
            },
            error: function(){
                  alert("error petición ajax");
            },
            success: function(data){
            	  //vaciar el contenido de una etiqueta html o elemento de formulario cuyo id sea 'etiq1'                                                   
                  //$("#etiq1").empty();

                  //mostrar el valor que tiene 'data' y lo añade al contenido de una etiqueta html o elemento de formulario cuyo id sea 'etiq1'        		  
                  //$("#etiq1").append(data);

       			  //recuperar información de fichero .php que envia lista de valores
                  //lista_datos = data[0];
                  //lista_datos2 = dato[1];		                                 
            }
	  }); 
	}

		
	//invocamos esta función cuando hacemos click al elemento de id="saludo"
	$("saludo").click(function(e){

	});

	$("#validarpregunta").click(function(e){
	   
	});

	
});

//invocación de funciones desde html con eventos ej. <button onclick="muestravalor(this.valor)"...

function muestraValor(val)
{
       document.getElementById("valorpreg").innerHTML=val;
}









