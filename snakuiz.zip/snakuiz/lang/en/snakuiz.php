<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.


/**
 * English strings for snakuiz
 *
 * You can have a rather longer description of the file as well,
 * if you like, and it can span multiple lines.
 *
 * @package    mod_snakuiz
 * @copyright  2011 Your Name
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['modulename'] = 'snakuiz';
$string['modulenameplural'] = 'snakuizs';
$string['modulename_help'] = 'Use the snakuiz module for... | The snakuiz module allows...';
$string['snakuizfieldset'] = 'Custom example fieldset';
$string['snakuizname'] = 'snakuiz name';

$string['snakuizname_help'] = 'This is the content of the help tooltip associated with the snakuizname field. Markdown syntax is supported.';
$string['snakuiz'] = 'snakuiz';
$string['pluginadministration'] = 'snakuiz administration';
$string['pluginname'] = 'snakuiz';


$string['startinglevel'] = 'Select the starting level';
$string['startinglevelhelp'] = 'Starting Level of the game: 1-10 where 1 is the slowest and 10 the fastest';
$string['numberquestions'] = 'Select the number of questions';
$string['numberquestionshelp'] = 'This option will create a number of prizes scattered, so each time the snake collide with one will show a question';

$string['option_questionbank'] = 'Moodle Native Questions Bank';
$string['option_questiontrivial'] = 'Trivial Like Questions';
$string['option_questionglobal'] = 'Global Like Questions';
$string['option_glossary'] = 'Glossary Like Questions';
$string['select_sourcequestions'] = 'Select the question source';
$string['sourcequestionshelp'] = 'The source from where we get the questions (Question Bank, Trivial or Global';

$string['sourcemodule_glossary'] = 'Select the glosary source';


$string['option_typemultiplechoice'] = 'Multiple Choice (3 questions)';
$string['option_typeshortanswer'] = 'Short Answer questions';
$string['option_typetruefalse'] = 'True/False questions';
$string['select_typequestions'] = 'Select the type of questions';
$string['typequestionshelp'] = 'Types of questions determine which kind of question to use';

$string['select_questionscategoryid'] = 'Select the Category of questions';
$string['questionscategoryidhelp'] = 'Questions Categories available';


