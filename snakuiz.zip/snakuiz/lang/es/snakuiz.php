<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.


/**
 * English strings for snakuiz
 *
 * You can have a rather longer description of the file as well,
 * if you like, and it can span multiple lines.
 *
 * @package    mod_snakuiz
 * @copyright  2011 Your Name
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['modulename'] = 'snakuiz';
$string['modulenameplural'] = 'snakuizs';
$string['modulename_help'] = 'Use the snakuiz module for... | The snakuiz module allows...';
$string['snakuizfieldset'] = 'Custom example fieldset';
$string['snakuizname'] = 'Nombre de snakuiz';


$string['snakuizname_help'] = 'This is the content of the help tooltip associated with the snakuizname field. Markdown syntax is supported.';
$string['snakuiz'] = 'snakuiz';
$string['pluginadministration'] = 'Administración de snakuiz';
$string['pluginname'] = 'snakuiz';


$string['startinglevel'] = 'Seleccione el nivel de inicio';
$string['startinglevelhelp'] = 'El nivel de inicio del juego (velocidad de la serpiente): 1-10 donde 1 es el más lento y 10 el más rápido';
$string['numberquestions'] = 'Seleccione el número de preguntas';
$string['numberquestionshelp'] = 'Esta opción creará un nº de premios esparcidos aleatoriamente, así que cada vez que la serpiente se encuente en su camino una, se mostrará una pregunta';

$string['option_questionbank'] = 'Banco de Preguntas Nativas de Moodle';
$string['option_questiontrivial'] = 'Preguntas Tipo Trivial';
$string['option_questionglobal'] = 'Preguntas Tipo Global';
$string['option_glossary'] = 'Preguntas del Glosario de Moodle';
$string['select_sourcequestions'] = 'Seleccione la fuente de las preguntas';
$string['sourcequestionshelp'] = 'La fuente de las preguntas corresponde al lugar desde el cual se seleccionan las preguntas. (Banco de Preguntas, Trivial,  Global y Glosario';

$string['sourcemodule_glossary'] = 'Seleccione la fuente del Glosario';


$string['option_typemultiplechoice'] = 'Preguntas Multiopción (siempre 3 opciones)';
$string['option_typeshortanswer'] = 'Preguntas de Respuesta Corta';
$string['option_typetruefalse'] = 'Preguntas Verdadero/Falso';
$string['select_typequestions'] = 'Seleccione el tipo de preguntas';
$string['typequestionshelp'] = 'El tipo de preguntas determina la tipología de preguntas a usar.';

$string['select_questionscategoryid'] = 'Seleccione la categoría de las preguntas';
$string['questionscategoryidhelp'] = 'Categorias de Preguntas disponibles';

