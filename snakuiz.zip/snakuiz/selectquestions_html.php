<?php

header('Content-Type: text/plain; charset=utf-8');


        /** El nombre de tu base de datos */
	define('DB_NAME', 'moodle26');

	/** Tu nombre de usuario de MySQL */
	define('DB_USER', 'root');

	/** Tu contraseña de MySQL */
	define('DB_PASSWORD', '123456');

	/** Host de MySQL (es muy probable que no necesites cambiarlo) */
	define('DB_HOST', 'localhost');

	/** Codificación de caracteres para la base de datos. */
	define('DB_CHARSET', 'utf8');


	$mysqli = mysqli_init();

	


	/* connect to server */
	$mysqli->real_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
        $mysqli->set_charset(DB_CHARSET);
	
        /* check connection */
	if (mysqli_connect_errno()) {
	    printf("Connect failed: %s\n", mysqli_connect_error());
	    exit();
	}


	


$id=$_POST['id'];
$startinglevel = $_POST['slevel'];
$numberquestions =  $_POST['nquestions'];
$sourcequestions = $_POST['squestions'];
$typequestions =  $_POST['tquestions'];
$questioncategoryid = $_POST['qcategoryid'];





$Questions = array();
$Options = array();
	
$questioncategoryid = '22';




    
if($sourcequestions == 'trivial'){
    $qsql = 'SELECT id, pregunta as quest, respuesta as answer FROM trivial ORDER BY RAND() LIMIT '. $numberquestions;
   

    if ($quests = $mysqli->query($qsql)) {
		$contador = 0;
                while ($quest = $quests->fetch_assoc()) {
                    $Questions[$contador] = strip_tags($quest["quest"]);
		            $Options[$contador] = strip_tags($quest["answer"]);    
		
		            $contador++;
	
                }
         
    }

}
else{
    $qsql = 'SELECT id, questiontext as quest FROM mdl_question WHERE category =' . $questioncategoryid . '  ORDER BY RAND() LIMIT '. $numberquestions;



    if ($quests = $mysqli->query($qsql)) {
		$contador = 0;
                while ($quest = $quests->fetch_assoc()) {
                    $Questions[$contador] = strip_tags($quest["quest"]);
		            $asql = 'SELECT * FROM mdl_question_answers WHERE question =' . $quest["id"] . ' ORDER BY fraction DESC LIMIT 3';	  
				    if ($answs = $mysqli->query($asql)) {
						while ($answ = $answs->fetch_assoc()) {
			                             $Options[$contador][] = strip_tags($answ["answer"]);
				        }
		            }
		
		         $contador++;
	
                }
    }
    
}
    



echo json_encode(array($Questions,$Options));
die(); 





?>


