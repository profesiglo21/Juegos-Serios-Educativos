$(document).ready(function() {
	

//no se usan sesiones en PHP
	
	// Creamos un contexto 2d de nuestro canvas
	var scanvas = $("#snake")[0];
	var contexto = scanvas.getContext("2d");
	var qcanvas = $("#quiz")[0];
    var context = qcanvas.getContext("2d");
	var width = $("#snake").width();
	var height = $("#snake").height();

	var cellWidth = 10;
	var d;
	var snake; // contiene el listado de celdas por donde pasa la serpiente
	var food;
	var prizes;
	var score;

	
	
	// Creamos un contexto 2d para el canvas del quiz
 	
	var quizbg = new Image();
	var snakebg = new Image();
	
	var Question = new String;
	var Option1 = new String;	
	var Option2 = new String;
	var Option3 = new String;      
    var respuesta = new String;
	var mx=0;
	var my=0;
	var CorrectAnswer = 0;
	var qnumber = 0;
	var rightanswers=0;
	var wronganswers=0;
	var QuizFinished = false;
	var lock = false;
	var textpos1=45;
	var textpos2=145;
	var textpos3=230;
	var textpos4=325;
	var Questions = new Array;
	var Options = new Array;
	var movimiento = 0;
	var cronometro;
	

    var instanceid = document.getElementById("instanceid").value;	
	var numberquestions = document.getElementById("numberquestions").value;       
	var sourcequestions = document.getElementById("sourcequestions").value;
	var typequestions = document.getElementById("typequestions").value;
	var questioncategoryid = document.getElementById("questioncategoryid").value;
	var glossaryid = document.getElementById("glossaryid").value;

    // valores iniciales de habilidad
	var level = document.getElementById("startinglevel").value; // 1 El nivel más lento, 10 el nivel más rápido.	
	var score = 0;
	var puntuacionquiz = 0;
	var cronoduracion = 0;
	var nvidas = 3;
	var puntuacionfinal = 0;
	var modo = 'final';     // Existen 2 modos: a. Entrenamiento, donde los prizes (preguntas ocultas) son visibles, pero no puntuan
							// b. final, los prizes aparecen ocultos y puntuan

	document.getElementById("boardnumpreguntas").innerHTML = numberquestions;
    document.getElementById("boardvelocidad").innerHTML = level;

	quizbg.onload = function(){
		context.drawImage(quizbg, 0, 0);
	};//quizbg

	snakebg.onload = function(){
		context.drawImage(snakebg, 0, 0);
	};//snakebg

	//lanza el canvas del snake
	//Init();
	
	quizbg.src = "images/quizbg.png";
	snakebg.src = "images/snakebg.jpg";

	//-------------- Controles Principales -----------------

	//Muestra la guía de usuario
	$("#info").click(function(e){
	  $.get('pinicial.html', function(data){
          modal.open({content: data});            
      });
	  return;	
	});	

	//lanza el juego en modo prueba/entrenamiento
	$("#train").click(function(e){
	  modo = 'entrenamiento'; 
	  movimiento=1;
	  Init();
	  return;	
	});

	//lanza el juego en modo final
	$("#game").click(function(e){
	  modo = 'final'; 
	  movimiento=1;	
	  Init();
	  return;	
	});

	//Muestra la guía de usuario
	$("#buttonsave").click(function(e){
	  $.get('pinicial.html', function(data){
          modal.open({content: data});            
      });
	  return;	
	});

	//lanza el juego en modo final
	$("#buttonpause").click(function(e){
	  if(movimiento==0){
	  		movimiento = 1;
	  		document.getElementById("lblpausar").innerHTML="pausar juego";
	  }
	  else{
	  		movimiento = 0;
	  		document.getElementById("lblpausar").innerHTML="continuar juego";
	  }
	  return;	
	});

	//lanza el juego en modo prueba/entrenamiento
	$("#buttonhistorico").click(function(e){	  
	  movimiento=1;	  
	  return;	
	});


	//-------------- Funciones Principales -----------------
	function CreateQuestions() {

	$.ajax({
            type: "POST",
            url: "selectquestions.php",
            data: "id="+instanceid+"&slevel="+level+"&nquestions="+numberquestions+"&squestions="+sourcequestions+"&tquestions="+typequestions+"&qcategoryid="+questioncategoryid+"&glossid="+glossaryid,
            dataType:"json",
            error: function(){
                  alert("error petición ajax");
            },
            success: function(data){       
		  Questions = data[0];
		  Options = data[1];
		  //alert(Questions);
		  //alert(Options);				                                 
            }
	  }); 
	}

	
    $("#validarRespuesta").click(function(e){

	   var respuesta_user = document.getElementsByName("useranswer")[0].value;
	   var respuesta_user_normalizada = normalize(respuesta_user).toLowerCase();
	   var respuesta_normalizada = normalize(respuesta).toLowerCase();
	   	  // alert(respuesta_normalizada + "---" + respuesta_user_normalizada);

	   if(respuesta_user_normalizada==respuesta_normalizada){
		//context.drawImage(quizbg, 0,400,75,70,480,110+(90*(a-1)),75,70);
		rightanswers++;
		
		puntuacionquizactual = CalculaPuntosPregunta(cronoduracion, score, level, nvidas);
		puntuacionquiz += puntuacionquizactual;
		document.getElementById("scorequiz").innerHTML = puntuacionquiz;
		//alert("Puntos Acumulados en Quiz: " + puntuacionquiz + "Crono: " + cronoduracion + "Punto acumulados Snake: " + score + "Velocidad: " + level + "Vidas: " + nvidas + "Puntos:" +CalculaPuntosPregunta(cronoduracion, score, level, nvidas));
	
		document.getElementById("feedback_msg").innerHTML="Enhorabuena, has acertado la pregunta";
        document.getElementById("icofeed").style.background="url('images/quizbg.png') 0px -400px";
        //document.getElementById("validar").disabled = true;

     
         

	   } 
	   else{
		wronganswers++;
		//alert('wrong: '+wronganswers);
		
		document.getElementById("feedback_msg").innerHTML=respuesta;
		document.getElementById("icofeed").style.background="url('images/quizbg.png')-76px -400px";
        //document.getElementById("validar").disabled = true;
           }
	   lock=true;
	});

	$("#continuar").click(function(e){
	    document.getElementsByName("useranswer")[0].value = '';
	    document.getElementById("feedback_msg").innerHTML = '';
	    document.getElementById("icofeed").style.background="url('images/img_trans.gif') 0px -400px";
	    if(lock)
	       ResetQ();
	});

 	function PaintQuestions(){			
        if(sourcequestions =='bank' && (typequestions == 'truefalse' || typequestions == 'multiplechoice')){	
			document.getElementById("quiz").style.display="block";
			context.clearRect(0,0,550,400);		
			context.drawImage(quizbg, 0, 0);
			
		}
        else
			document.getElementById("quiz_html").style.display="block";

		SetQuestions();
	}



	
function SetQuestions(){
             

		Question=Questions[qnumber];
		if(sourcequestions =='bank' && (typequestions == 'truefalse' || typequestions == 'multiplechoice')){		
			if(typequestions == 'truefalse'){
			    CorrectAnswer = 1+Math.floor(Math.random()*2);
			    if(CorrectAnswer==1){
					Option1=Options[qnumber][0];Option2=Options[qnumber][1];
				}
				if(CorrectAnswer==2){
					Option1=Options[qnumber][1];Option2=Options[qnumber][0];
				}
					
				context.textBaseline = "middle";
				context.font = "12pt Calibri,Arial";
				context.fillText(Question,20,textpos1);
				context.font = "10pt Calibri,Arial";
				context.fillText(Option1,20,textpos2);
				context.fillText(Option2,20,textpos3);
				
			}
			else if(typequestions == 'multiplechoice'){
			    CorrectAnswer = 1+Math.floor(Math.random()*3);		

				if(CorrectAnswer==1){
					Option1=Options[qnumber][0];Option2=Options[qnumber][1];Option3=Options[qnumber][2];
				}
				if(CorrectAnswer==2){
					Option1=Options[qnumber][2];Option2=Options[qnumber][0];Option3=Options[qnumber][1];
				}
				if(CorrectAnswer==3){
					Option1=Options[qnumber][1];Option2=Options[qnumber][2];Option3=Options[qnumber][0];
				}		
				context.textBaseline = "middle";
				context.font = "12pt Calibri,Arial";
				context.fillText(Question,20,textpos1);
				context.font = "10pt Calibri,Arial";
				context.fillText(Option1,20,textpos2);
				context.fillText(Option2,20,textpos3);
				context.fillText(Option3,20,textpos4);
			}
		}
		else
 		{    
          	
			respuesta=Options[qnumber];
			var respuesta_normalizada = normalize(respuesta);
			var respuesta_oculta = respuesta_normalizada.toLowerCase().replace(/[a-z,0-9]/gi,'-');
	
			document.getElementById("question").innerHTML=Question;	
			document.getElementById("pista").innerHTML=respuesta_oculta;		
		}
			


	}//SetQuestions



    //Devuelve los pixeles de coordenadas según los pixels que se encuentran bajo el cursor de ratón
	HTMLCanvasElement.prototype.relativeCoords = function(event) {
	  var x,y;

	  var rect = this.getBoundingClientRect();
	  x = event.clientX - rect.left;
	  y = event.clientY - rect.top;
	  var width = rect.right - rect.left;
	 
	  if(this.width!=width) {
	    var height = rect.bottom - rect.top;
	   
	    x = x*(this.width/width);
	    y = y*(this.width/height);
	  } 
	  //Devuelve un array con las coordenadas
	  return [x,y];
	};

    /* 
        var x = document.getElementById("x");
	var y = document.getElementById("y");
	qcanvas.addEventListener("mousemove", function(event) {
	    var coords = qcanvas.relativeCoords(event);
	    x.innerHTML = Math.round(coords[0]);
	    y.innerHTML = Math.round(coords[1]);
	});
    */

	qcanvas.addEventListener('click',ProcessClick,false);

	function ProcessClick(ev) {

		var coordenadas = qcanvas.relativeCoords(ev);
		
		mx = Math.round(coordenadas[0]);
		my = Math.round(coordenadas[1]);
		//alert ("mx:" + mx + " my:" + my);
                
		if(lock){
			ResetQ();
		}
		else{

			if(my>110 && my<180){GetFeedback(1);}
			if(my>200 && my<270){GetFeedback(2);}

			if(typequestions == 'multiplechoice')
			    if(my>290 && my<360){GetFeedback(3);}

		}//!lock

	}//ProcessClick


	// El juego tiene la dirección "right" por defecto y se ejecuta la función paint
	// dependiendo el nivel que hayas configurado arriba
	function Init()
	{
        document.getElementById("snake").style.display="block";
        document.getElementById("fondocanvasnake").style.display="block";
        document.getElementById("quiz").style.display="none";


        // Valores de inicio
        CorrectAnswer = 0;
		qnumber = 0;
		rightanswers=0;
		wronganswers=0;
		QuizFinished = false;
		lock = false;
		score = 0;
		puntuacionquiz = 0;
	    cronoduracion = 0;
		nvidas = 3;
		puntuacionfinal = 0;
		d = "right";

		CreateSnake();
		CreateFood();
		CreateQuestions();
		CreatePrizes();
		
		

		if(typeof cronometro != "undefined") {
			clearInterval(cronometro);
        }

        cargaCronometro();
       

		if(typeof gameLoop != "undefined") {
			clearInterval(gameLoop);
		}
 
		gameLoop = setInterval(function() {
		  if(movimiento) { 
		    Paint();
		  } 		  
		}, 1500 / level);


        
	
	}
	
	function GetFeedback(a){

		  if(a==CorrectAnswer){
		  	context.drawImage(quizbg, 0,400,75,70,480,110+(90*(a-1)),75,70);
			rightanswers++;
			puntuacionquizactual = CalculaPuntosPregunta(cronoduracion, score, level, nvidas);
			puntuacionquiz += puntuacionquizactual;
			document.getElementById("scorequiz").innerHTML = puntuacionquiz;
			//alert("Puntos Acumulados en Quiz: " + puntuacionquiz + " Crono: " + cronoduracion + " Puntos Acumulados por Snake: " + score + "Velocidad: " + level + "Vidas: " + nvidas + "Puntos:" +CalculaPuntosPregunta(cronoduracion, score, level, nvidas));
	
		  }
		  else{
		    	context.drawImage(quizbg, 75,400,75,70,480,110+(90*(a-1)),75,70);
			wronganswers++;
		  }
		  lock=true;
		  context.font = "14pt Calibri,Arial";
		  context.fillText("Click again to continue",20,380);
		  
	}//get feedback

	


	function ResetQ(){
		lock=false;
		
		qnumber++;
		if(qnumber==Questions.length){
			EndQuiz();
		}
		else{
                        			
			PaintQuestions();
			movimiento = 1;	
			if(sourcequestions =='bank' && (typequestions == 'truefalse' || typequestions == 'multiplechoice'))
			    document.getElementById("quiz").style.display = 'none';	
			else
				document.getElementById("quiz_html").style.display = 'none';	
		}
	}


	function EndQuiz(){

		puntuacionfinal = puntuacionquiz + (score * 100);

		
	    document.getElementById("quiz").style.display = 'block';	
	    document.getElementById("quiz_html").style.display = 'none';
	    document.getElementById("fondocanvasnake").style.display = 'none';
	    document.getElementById("boardvidas").innerHTML = 0;

			
		qcanvas.removeEventListener('click',ProcessClick,false);
		context.clearRect(0,0,550,400);	
		context.drawImage(quizbg, 0,0,550,90,0,0,550,400);
		context.font = "20pt Calibri,Arial";
		context.fillText("¡El Cuestionario (Quiz) ha concluido!",20,100);
		context.font = "16pt Calibri,Arial";

		context.fillText("Número de Preguntas: "+String(Questions.length),20,160);
		context.fillText("Respuestas Correctas: "+String(rightanswers),20,200);
		context.fillText("Respuestas Equivocadas: "+String(wronganswers),20,240);
		context.fillText("Número de Manzanas Comidas: "+String(score),20,280);
		context.fillText("Puntuación TOTAL: "+String(puntuacionfinal),20,320);

		//alert("Game Over: Puntuacion Final: " + puntuacionfinal  + " Total Preguntas: "+ Questions.length +  " Score: "+ score + " Correct answers: "+String(rightanswers) + " Wrong answers: "+String(wronganswers));
		    	
		
	}


	function cargaCronometro()
	{   
		contador_s =0;
		contador_m =0;	

		cronometro = setInterval(
			function(){
				if(contador_s == 60)
				{	contador_s = 0;
					contador_m++;
					if(contador_m == 60)					
						contador_m=0;					
				}

				contador_s++;
				cronoduracion++;

				cronoText = contador_m + " min. " + contador_s + " seg.";				
				document.getElementById("boardcrono").innerHTML = cronoText;
			}
			,1000);
	}
			
	
	


	function continuePlay()
	{

		d = "right"; 
		CreateSnake();
		CreateFood();

		if(typeof gameLoop != "undefined") {
			clearInterval(gameLoop);
		}
 
		gameLoop = setInterval(function() {
		  if(movimiento) { 
		    Paint();
		  } 		  
		}, 1500 / level);
	
	}
 
	

	// Creamos la serpiente
	function CreateSnake()
	{       var length = 5;
		snake = []; 
 
		for(var i = length - 1; i >= 0; i--)
		{
			snake.push({ x: i, y: 0 });
		}
	}

	//Creamos el recuado que tiene que comerse la serpiente
	function CreateFood()
	{
		food = {
			x: Math.round(Math.random() * (width - cellWidth) / cellWidth), 
			y: Math.round(Math.random() * (height - cellWidth) / cellWidth) 
		};
	}

	function CreatePrizes()
	{
		prizes = []; 
 
		for(var i = 0; i < numberquestions; i++)
		{
			prizes.push({ x: Math.round(Math.random() * (width - cellWidth) / cellWidth), 
			              y: Math.round(Math.random() * (height - cellWidth) / cellWidth)
				   });
		}
		
	}

	//Dibujamos la serpiente
	function Paint()
	{
		contexto.fillStyle = "rgb(215,255,81)";
		contexto.fillRect(0, 0, width, height);
		//contexto.drawImage(snakebg, 0,0,450,450,0,0,450,450);
		contexto.strokeStyle = 'black';
		contexto.strokeRect(0, 0, width, height);	
		
		var nx = snake[0].x;
		var ny = snake[0].y;
		
		if (d == "right") {
			nx++;
		} else if (d == "left") {
			nx--;
		} else if (d == "up") {
			ny--;
		} else if (d == "down") {
			ny++;
		}
		
		if (nx == -1 || nx == width / cellWidth || ny == -1 || ny == height / cellWidth || CheckCollision(nx, ny, snake)) {			
			//Init();
		    nvidas--;
		    switch(nvidas){
		    	case 2:
		    		document.getElementById("vida3").style.display="none";
		    		break;
		    	case 1:
		    		document.getElementById("vida2").style.display="none";
		    		break;
		    	case 0:
		    		document.getElementById("vida1").style.display="none";
		    		break;
		    }
		    
			if(nvidas <= 0){
				lock=false;		       
		        movimiento=0;		    
		        document.getElementById("quiz").style.display="block";
		        document.getElementById("snake").style.display="none";
		        document.getElementById("fondocanvasnake").style.display="none";
		        context.clearRect(0,0,550,400);
				EndQuiz();
				return;
		    }		
			else
			{	

 			    continuePlay();
 			    return;
			}
		
		}
		
		if(nx == food.x && ny == food.y) {
			var tail = {
				x: nx, 
				y: ny
			};
			score++;
			document.getElementById("scoresnake").innerHTML = score*100;

			//puntuacionfinal += score * 100;
			CreateFood();
		} 
		else {  
			var p;
			var condicion = false;
			for(var i = 0; i < prizes.length; i++) {
				p = prizes[i];
				if(nx == p.x && ny == p.y){
					
					condicion = true;					
				}
				   		
			}

			if(condicion) {
				
				
				var tail = {
					x: nx, 
					y: ny
				};
				//score++;
	
				movimiento = 0;	
				PaintQuestions();
				numberquestions--;
				CreatePrizes();
								
				CreateFood();
								
				
				//CreatePrizes();
			} 							
			else {
				var tail = snake.pop(); 	 
				tail.x = nx;
				tail.y = ny;
			}
		}

		/*for(var i = 0; i < prizes.length; i++) {
			var p = prizes[i];
			if(nx == p.x && ny == p.y) { 
				PaintQuestions();
				CreateFood();
				CreatePrizes();
			}
			else {
				var tail = snake.pop(); 
	 
				tail.x = nx;
				tail.y = ny;
			}	
	        }*/
		
			
                snake.unshift(tail); 
		
		for(var i = 0; i < snake.length; i++) {
			var c = snake[i];
			PaintCell(c.x, c.y, "rgb(67,118,162)", "white");
		}

		PaintCell(food.x, food.y, "rgb(173,37,37)", "white");


		for(var i = 0; i < prizes.length; i++) {
			var p = prizes[i];
			if(modo == 'entrenamiento')
				PaintCell(p.x, p.y, "yellow", "black");
			else
				PaintCell(p.x, p.y, "rgba(255,255,255,0)", "rgba(255,255,255,0)");
		}

		/*var scoreText = "Score: " + score * 100;
		contexto.fillStyle= "blue";
		contexto.fillText(scoreText, 5, height - 5);
		*/

	
	}

	function CalculaPuntosPregunta(instantetiempo, score, velocidad, numvidas)
	{
		//100+((1000−tiempo)+(score×velocidad×numerovidas))  donde 100 es fijo, (1000-tiempo) >= 0

		var comptemporal;
		var compfijo;
		var comphabilidad;
		var puntuacion;

		compfijo = 100;
		comptemporal = 1000 - instantetiempo;
		if(comptemporal < 0)
			comptemporal = 0;
		comphabilidad = score * velocidad * numvidas;

		puntuacion = compfijo + comptemporal + comphabilidad;

		return puntuacion;
	}
	
	//Pintamos la celda	
	function PaintCell(x, y, fcolor, scolor )
	{
		contexto.fillStyle = fcolor;
		contexto.fillRect(x * cellWidth, y * cellWidth, cellWidth, cellWidth);
		contexto.strokeStyle = scolor;
		contexto.strokeRect(x * cellWidth, y * cellWidth, cellWidth, cellWidth);
	}
	
	
	//Verificiamos si hubo alguna colisión (si la hubo el juego se reinicia)
	function CheckCollision(x, y, array)
	{
		for(var i = 0; i < array.length; i++)
		{
			if(array[i].x == x && array[i].y == y) {
				
				return true;
			}
		}
 		return false;
	}
		
	// Capturamos la pulsación de las teclas
	$(document).keydown(function(e) {
		var key = e.which;
		
		if (key == "37" && d != "right") {
			d = "left";
		} else if (key == "38" && d != "down") {
			d = "up";
		} else if (key == "39" && d != "left") {
			d = "right";
		} else if (key == "40" && d != "up") {
			d = "down";
		}
	});

	var normalize = (function() {
		var from = "ÃÀÁÄÂÈÉËÊÌÍÏÎÒÓÖÔÙÚÜÛãàáäâèéëêìíïîòóöôùúüûÑñÇç";
		var to   = "AAAAAEEEEIIIIOOOOUUUUaaaaaeeeeiiiioooouuuunncc";
		var mapping = {};
		 
		  for(var i = 0, j = from.length; i < j; i++ )
		      mapping[ from.charAt( i ) ] = to.charAt( i );
		 
		  return function( str ) {
		      var ret = [];
		      for( var i = 0, j = str.length; i < j; i++ ) {
			  var c = str.charAt( i );
			  if( mapping.hasOwnProperty( str.charAt( i ) ) )
			      ret.push( mapping[ c ] );
			  else
			      ret.push( c );
		      }      
		      return ret.join( '' );
		  }
		 
	})();
});

	

	
