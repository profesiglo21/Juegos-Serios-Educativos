<?php

require_once(dirname(dirname(dirname(__FILE__))).'/config.php');
require_once(dirname(__FILE__).'/lib.php');
$id=$_POST['id'];
$startinglevel = $_POST['slevel'];
$numberquestions =  $_POST['nquestions'];
$sourcequestions = $_POST['squestions'];
$typequestions =  $_POST['tquestions'];
$questioncategoryid = $_POST['qcategoryid'];
$glossaryid = $_POST['glossid'];

$Questions = array();
$Options = array();
	


if ($id) {
    $cm         = get_coursemodule_from_id('snakuiz', $id, 0, false, MUST_EXIST);
    $course     = $DB->get_record('course', array('id' => $cm->course), '*', MUST_EXIST);
    $snakuiz  = $DB->get_record('snakuiz', array('id' => $cm->instance), '*', MUST_EXIST);

  
  if($sourcequestions == 'trivial' || $sourcequestions == 'global' || ($sourcequestions == 'bank' && $typequestions == 'shortanswer') || $sourcequestions == 'glossary'){
  	    
  	    if($sourcequestions == 'trivial' || $sourcequestions == 'global') 
  	       $qsql = 'SELECT id, pregunta as quest, respuesta as answer FROM ' . $sourcequestions . ' ORDER BY RAND() LIMIT '. $numberquestions;
	    else if($sourcequestions == 'bank' && $typequestions == 'shortanswer') 
	        $qsql = 'SELECT q.id, q.questiontext as quest, a.answer FROM {question} AS q, {qtype_shortanswer_options} AS s, {question_answers} AS a WHERE a.question = q.id AND q.id = s.questionid AND q.category = '. $questioncategoryid . ' ORDER BY RAND() LIMIT '. $numberquestions;
	    else if($sourcequestions == 'glossary')   	      
	    	$qsql = 'SELECT definition as quest, concept as answer FROM {glossary_entries} WHERE glossaryid = ' . $glossaryid  .' ORDER BY RAND() LIMIT '. $numberquestions;

        //$qsql = 'SELECT id, pregunta as quest, respuesta as answer FROM trivial ORDER BY RAND() LIMIT '. $numberquestions;

	    if ($quests = $DB->get_records_sql($qsql)) {
			$contador = 0;
		        
            foreach ($quests as $pregunta) {
		            $Questions[$contador] = strip_tags($pregunta->quest);
		            $Options[$contador] = strip_tags($pregunta->answer);    
		
				    $contador++;
			}		       
	    }
  }
  else {  
	    switch ($typequestions) {
		    case 'multiplechoice':
		       $qsql = 'SELECT q.id, q.questiontext FROM {question} AS q, {qtype_multichoice_options} AS m WHERE q.id = m.questionid AND q.category ='. $questioncategoryid . ' ORDER BY RAND() LIMIT ' . $numberquestions;		
			break;	    
		    case 'truefalse':
			$qsql = 'SELECT q.id, q.questiontext FROM {question} AS q, {question_truefalse} AS t WHERE q.id = t.question AND q.category ='. $questioncategoryid . ' ORDER BY RAND() LIMIT ' . $numberquestions;
			break;
		    default:
			$qsql = 'SELECT q.id, q.questiontext FROM {question} WHERE category =' . $questioncategoryid . '  ORDER BY RAND() LIMIT ' . $numberquestions;
		}


	    if ($quests = $DB->get_records_sql($qsql)) {
			$contador = 0;
	                foreach ($quests as $quest) {
	                    $Questions[$contador] = strip_tags($quest->questiontext);
			    $asql = 'SELECT * FROM {question_answers} WHERE question =' . $quest->id . ' ORDER BY fraction DESC LIMIT 3';
			  
			    if ($answs = $DB->get_records_sql($asql)) {
				 foreach ($answs as $answ) {
	                             $Options[$contador][] = strip_tags($answ->answer);
				 }
			    }
			
			$contador++;
		
	                }
	    }
  }
    
}           
else {
    error('You must specify a course_module ID or an instance ID');
}


echo json_encode(array($Questions,$Options));
die(); 





?>


