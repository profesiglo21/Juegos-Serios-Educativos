<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Prints a particular instance of snakuiz
 *
 * You can have a rather longer description of the file as well,
 * if you like, and it can span multiple lines.
 *
 * @package    mod_snakuiz
 * @copyright  2011 Your Name
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

/// (Replace snakuiz with the name of your module and remove this line)

require_once(dirname(dirname(dirname(__FILE__))).'/config.php');
require_once(dirname(__FILE__).'/lib.php');



$id = optional_param('id', 0, PARAM_INT); // course_module ID, or
$n  = optional_param('n', 0, PARAM_INT);  // snakuiz instance ID - it should be named as the first character of the module

if ($id) {
    $cm         = get_coursemodule_from_id('snakuiz', $id, 0, false, MUST_EXIST);
    $course     = $DB->get_record('course', array('id' => $cm->course), '*', MUST_EXIST);
    $snakuiz  = $DB->get_record('snakuiz', array('id' => $cm->instance), '*', MUST_EXIST);
    if ($recs = $DB->get_records('snakuiz', array('id' => $cm->instance), 'id,startinglevel,numberquestions,sourcequestions,typequestions,questioncategoryid,glossaryid')) {
                foreach ($recs as $rec) {
		    $instanceid = $id;
            $startinglevel = $rec->startinglevel;
		    $numberquestions = $rec->numberquestions;  
		    $sourcequestions = $rec->sourcequestions;
		    $typequestions = $rec->typequestions;
		    $questioncategoryid = $rec->questioncategoryid; 
            $glossaryid = $rec->glossaryid;           
                }
   }
           
} elseif ($n) {
    $snakuiz  = $DB->get_record('snakuiz', array('id' => $n), '*', MUST_EXIST);
    $course     = $DB->get_record('course', array('id' => $snakuiz->course), '*', MUST_EXIST);
    $cm         = get_coursemodule_from_instance('snakuiz', $snakuiz->id, $course->id, false, MUST_EXIST);
    if ($recs = $DB->get_records('snakuiz', array('id' => $cm->instance), 'id,startinglevel,numberquestions,sourcequestions,typequestions,questioncategoryid,glossaryid')) {
                foreach ($recs as $rec) {
		    $instanceid = $n;
            $startinglevel = $rec->startinglevel;
		    $numberquestions = $rec->numberquestions;  
		    $sourcequestions = $rec->sourcequestions;
		    $typequestions = $rec->typequestions;
		    $questioncategoryid = $rec->questioncategoryid;  
            $glossaryid = $rec->glossaryid;           
                }
    }
           

} else {
    error('You must specify a course_module ID or an instance ID');
}

require_login($course, true, $cm);
$context = context_module::instance($cm->id);
add_to_log($course->id, 'snakuiz', 'view', "view.php?id={$cm->id}", $snakuiz->name, $cm->id);

/// Print the page header
$PAGE->set_url('/mod/snakuiz/view.php', array('id' => $cm->id));
$PAGE->set_title(format_string($snakuiz->name));
$PAGE->requires->css('/mod/snakuiz/snakuiz.css', true);
$PAGE->requires->css('/mod/snakuiz/modal.css', true);

//inclusion del javascript para las funciones
$PAGE->requires->js('/mod/snakuiz/js/jquery.js', true);
$PAGE->requires->js('/mod/snakuiz/js/snakuiz.js', true);
$PAGE->requires->js('/mod/snakuiz/js/modal.js', true);

$PAGE->set_heading(format_string($course->fullname));
$PAGE->set_context($context);

// other things you may want to set - remove if not needed
$PAGE->set_cacheable(false);
//$PAGE->set_focuscontrol('some-html-id');
//$PAGE->add_body_class('snakuiz-'.$somevar);

// Output starts here
echo $OUTPUT->header();
if ($snakuiz->intro) { // Conditions to show the intro can change to look for own settings or whatever
    echo $OUTPUT->box(format_module_intro('snakuiz', $snakuiz, $cm->id), 'generalbox mod_introbox', 'snakuizintro');
}

// Replace the following lines with you own code
echo $OUTPUT->heading('
    <input id="instanceid" type="hidden" value="'.$instanceid.'">
    <input id="startinglevel" type="hidden" value="'.$startinglevel.'">
    <input id="numberquestions" type="hidden" value="'.$numberquestions.'">
    <input id="sourcequestions" type="hidden" value="'.$sourcequestions.'">
    <input id="typequestions" type="hidden" value="'.$typequestions.'">
    <input id="questioncategoryid" type="hidden" value="'.$questioncategoryid.'">
    <input id="glossaryid" type="hidden" value="'.$glossaryid.'">

    <div id="ccontainer">        
        <div id="board">
            <div id="boardlogo"><img src="images/logo_verde_small.png" width="85%"></div>
            <div id="boardscore">
                Puntuación Snake: <span id="scorequiz" class="negrita">0</span><br>
                Puntuación Quiz: <span id="scoresnake" class="negrita">0</span>
            </div>
            <div id="boardcronovidas">
                Tiempo de juego:<br><span id="boardcrono" class="negrita">0 min. 0 seg.</span><br>
                Número de vidas:<br><span id="boardvidas">
                    <img id="vida1" src="images/snake_vidas_1.png" width="20">
                    <img id="vida2" src="images/snake_vidas_2.png" width="20">
                    <img id="vida3" src="images/snake_vidas_3.png" width="20">
                </span><br>
                Speed: <span id="boardvelocidad"></span> y Nº Preguntas: <span id="boardnumpreguntas"></span>
            </div>            
            <div id="boardmenu">
                <span id="info"><input id="manual" type="image" src="images/ribbon_blue_blank.png" alt="Ver Manual de Usuario"></span>
                <span id="go_instruc"><input id="train" type="image" src="images/ribbon_grey.png" alt="Ver las instrucciones del juego"></span>
                <span id="go_game"><input id="game" type="image" src="images/ribbon_yellow.png" alt="Ir al panel de ajustes"></span>
            </div>           
        </div>        
        <div id="main">          
            <div id="quiz_html">
                <span id="question"></span>
                <span id="answer"><input name="useranswer" type="text" size="45%" placeholder="Inserta la respuesta" />
                <button id="validarRespuesta">Validar</button>
                </span>
                <span id="tip">
                    <input type="image" src="images/pista.png" alt="pista 1 - 75% de la puntuación">
                    <input type="image" src="images/pista.png" alt="pista 2 - 50% de la puntuación">
                    <input type="image" src="images/pista.png" alt="pista 3 - 25%"><span id="pista"></span></span> <span id="feedback">
                    <span id="feedback_msg"></span>
                    <span id="iconfeed"><img id="icofeed" src="images/img_trans.gif" align="middle"></span>
                </span>
                <span id="continuar">Click again to continue</span>
            </div>
            <canvas id="quiz" width="550" height="400"></canvas>
            <div id="fondocanvasnake"><canvas id="snake" width="450" height="450"></canvas></div>
                <span id="buttonsave"><label>Guardar</label><input id="pf_grabar" type="image" src="images/boton_red_small.png" alt="Grabar jugada" target="_blank"></span>
                <span id="buttonpause"><label id="lblpausar">Pausar Juego</label><input id="pf_menu" type="image" src="images/boton_blue_small.png" alt="Volver a menú principal"></span>
                <span id="buttonhistorico"><label>Histórico</label><input id="pf_historico" type="image" src="images/boton_green_small.png" alt="Ver el histórico de puntuaciones"></span>    
            </div>
            <div id="license">Common Creative Licence - Salim Tieb Mohamedi</div>       
        </div>');

// Finish the page
echo $OUTPUT->footer();
