<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * The main snakuiz configuration form
 *
 * It uses the standard core Moodle formslib. For more info about them, please
 * visit: http://docs.moodle.org/en/Development:lib/formslib.php
 *
 * @package    mod_snakuiz
 * @copyright  2011 Your Name
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

require_once($CFG->dirroot.'/course/moodleform_mod.php');
require( 'locallib.php');

/**
 * Module instance settings form
 */
class mod_snakuiz_mod_form extends moodleform_mod {

    /**
     * Defines forms elements
     */
    public function definition() {

	global $CFG, $DB, $COURSE;

        $config = get_config('snakuiz');
        $id = $this->_instance;
        $mform = $this->_form;

        //-------------------------------------------------------------------------------
        // Adding the "general" fieldset, where all the common settings are showed
        $mform->addElement('header', 'general', get_string('general', 'form'));

        // Adding the standard "name" field
        $mform->addElement('text', 'name', get_string('snakuizname', 'snakuiz'), array('size'=>'64'));
        if (!empty($CFG->formatstringstriptags)) {
            $mform->setType('name', PARAM_TEXT);
        } else {
            $mform->setType('name', PARAM_CLEAN);
        }
        $mform->addRule('name', null, 'required', null, 'client');
        $mform->addRule('name', get_string('maximumchars', '', 255), 'maxlength', 255, 'client');
        $mform->addHelpButton('name', 'snakuizname', 'snakuiz');

        // Adding the standard "intro" and "introformat" fields
        $this->add_intro_editor();

        //-------------------------------------------------------------------------------
        // Adding the rest of snakuiz settings, spreeading all them into this fieldset
        // or adding more fieldsets ('header' elements) if needed for better logic
        
	
	$mform->addElement('text', 'startinglevel', get_string('startinglevel', 'snakuiz'));
    $mform->setType('startinglevel', PARAM_INT);
    $mform->setDefault('startinglevel', 5);
	$mform->addHelpButton('param1', 'startinglevelhelp', 'snakuiz');

	$mform->addElement('text', 'numberquestions', get_string('numberquestions', 'snakuiz'));
    $mform->setType('numberquestions', PARAM_INT);
    $mform->setDefault('numberquestions', 10);
	$mform->addHelpButton('param1', 'numberquestionshelp', 'snakuiz');

	$questionsourceoptions = array();
       
    $questionsourceoptions['bank'] = get_string('option_questionbank', 'snakuiz');     
    $questionsourceoptions['trivial'] = get_string('option_questiontrivial', 'snakuiz');      
    $questionsourceoptions['global'] = get_string('option_questionglobal', 'snakuiz');
	$questionsourceoptions['glossary'] = get_string('option_glossary', 'snakuiz');
      
    $mform->addElement('select', 'sourcequestions', get_string('select_sourcequestions', 'snakuiz'), $questionsourceoptions);
	$mform->setType('sourcequestions', PARAM_TEXT);
    $mform->setDefault('sourcequestions', 'bank');
	$mform->addHelpButton('sourcequestions', 'sourcequestionshelp', 'snakuiz');

    
    
	$questiontypeoptions = array();        

    /*if ($data->sourcequestions == ''){
        // Process the department fields only

    } 
    else if (isset($data->submitsection)){
        // Process the area fields only

    }*/

    $questiontypeoptions['shortanswer'] = get_string('option_typeshortanswer', 'snakuiz');
    $questiontypeoptions['multiplechoice'] = get_string('option_typemultiplechoice', 'snakuiz');   
    $questiontypeoptions['truefalse'] = get_string('option_typetruefalse', 'snakuiz');     
    
	
    
    $mform->addElement('select', 'typequestions', get_string('select_typequestions', 'snakuiz'), $questiontypeoptions);
	$mform->setType('typequestions', PARAM_TEXT);
        $mform->setDefault('typequestions', 'shortanswer');
	$mform->addHelpButton('typequestions', 'typequestionshelp', 'snakuiz');
     $mform->disabledIf('typequestions', 'sourcequestions', 'neq', 'bank');

        $questioncategoriesoptions = array();
        if ($recs = $DB->get_records_select('question_categories', $select, null, 'id,name')) {
                foreach ($recs as $rec) {
                    $s = $rec->name;
                    if (($count = $DB->count_records('question', array( 'category' => $rec->id))) != 0) {
                        $s .= " ($count)";
                    }
                    $questioncategoriesoptions[$rec->id] = $s;
                }
         }

        $mform->addElement('select', 'questioncategoryid', get_string('select_questionscategoryid', 'snakuiz'), $questioncategoriesoptions );
	$mform->setType('questioncategoryid', PARAM_TEXT);
        $mform->setDefault('questioncategoryid', 'default');
	$mform->addHelpButton('questioncategoryid', 'questionscategoryidhelp', 'snakuiz');
     $mform->disabledIf('questioncategoryid', 'sourcequestions', 'neq', 'bank');
        $a = array();
        if ($recs = $DB->get_records('glossary', array( 'course' => $COURSE->id), 'id,name')) {
                foreach ($recs as $rec) {
                    $a[$rec->id] = $rec->name;
                }
        }
        $mform->addElement('select', 'glossaryid', get_string('sourcemodule_glossary', 'snakuiz'), $a);
          $mform->setDefault('glossaryid', 'default');
        $mform->disabledIf('glossaryid', 'sourcequestions', 'neq', 'glossary');

	
	

        //-------------------------------------------------------------------------------
        // add standard elements, common to all modules
        $this->standard_coursemodule_elements();
        //-------------------------------------------------------------------------------
        // add standard buttons, common to all modules
        $this->add_action_buttons();
    }

    public function validation($data, $files) {
        $errors = parent::validation($data, $files);
        return $errors;
    }


    public function set_data($defaultvalues) {
         
        parent::set_data($defaultvalues);
    }

    

}
