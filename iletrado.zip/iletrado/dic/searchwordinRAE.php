<?php


$noseencuentra = 'no est&aacute; registrada en el Diccionario';

$palabrabuscada = "ornamento";
$url = "http://dle.rae.es/srv/search?w=" . $palabrabuscada;
$html = file_get_contents($url);

$pos1 = stripos($html, $noseencuentra);

// No, 'a' sin duda no está en 'xyz'
if ($pos1 === false) {
    //echo "El string '$noseencuentra' no se encontró en el string <br/>'$html'";
    echo "La palabra '$palabrabuscada' SI existe ";
}
else
    echo "La palabra '$palabrabuscada' NO existe ";


