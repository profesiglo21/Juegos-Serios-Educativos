
$(document).ready(function() 
{ 	
	
	//hacemos focus al campo de búsqueda
	$("#busqueda").focus();
	
	
   function palabraEnDiccionario() {

    //obtenemos el texto introducido en el campo de búsqueda
	consulta = $("#busqueda").val();
	                                                         
	//hace la búsqueda
	$.ajax({
            type: "POST",
            url: "comprobarpalabra_es.php",
            data: "palabra="+consulta,
            dataType: "html",
            beforeSend: function(){
                  //imagen de carga
                  $("#relojimage").html("<p align='center'><img src='reloj.gif'/></p>");
            },
            error: function(){
                  alert("error petición ajax");
            },
            success: function(data){                                                    
                  $("#relojimage").empty();		  
                  $("#resultado").append(data);		                                 
            }
	  }); 
	}

		
	
	$("#comprobarPalabra").click(function(e){
	    document.getElementById('resultado').innerHTML='';		
		 
		palabraEnDiccionario();	
	});

	
});



