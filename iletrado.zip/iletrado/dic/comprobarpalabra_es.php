<?php
header('Content-Type: text/plain; charset=utf-8');
$buscar = $_POST['palabra'];
$contar = 0;

/** El nombre de tu base de datos */
define('DB_NAME', 'test');

/** Tu nombre de usuario de MySQL */
define('DB_USER', 'root');

/** Tu contraseña de MySQL */
define('DB_PASSWORD', '123456');

/** Host de MySQL (es muy probable que no necesites cambiarlo) */
define('DB_HOST', 'localhost');

/** Codificación de caracteres para la base de datos. */
define('DB_CHARSET', 'utf8');

	function conectarBD()
    {
		/* create a connection object which is not connected */
		$mysqli = mysqli_init();

		/* set connection options */
		$mysqli->options(MYSQLI_OPT_LOCAL_INFILE, true);

		/* connect to server */
		$mysqli->real_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
		$mysqli->set_charset(DB_CHARSET);
			
		/* check connection */
		if (mysqli_connect_errno()) {
				printf("Conexión fallida: %s\n", mysqli_connect_error());
				exit();
		}		
		return $mysqli;
	}


	if(isset($buscar)) {
	    $conexion = conectarBD();
		buscarPalabra($buscar);	
		
		if ($contar>0)
			echo "1";              
		else{
			buscarPalabraRAE($buscar);
                }
    }
 
    function buscarPalabra($b)
    {
		global $contar;
		global $conexion;
			
		$sql = "SELECT * FROM mydiccionario_esNew WHERE palabra = '".$b."'";
		
		if ($result = $conexion->query($sql)) {
			/* determinar el número de filas del resultado */
			$contar = $result->num_rows;			   
			$result->close();
		}	
      }     
      
      
   function buscarPalabraRAE($b)
    {
        $noseencuentra = 'no est&aacute; registrada en el Diccionario';

        $url = "http://dle.rae.es/srv/search?w=" . $b;
		
		$conexion = @fsockopen(url, 80, $errno, $errstr, 30); 

		if (!$conexion) { 
			echo "0"; 
			die();
		} else { 
			echo "1"; 
			fclose($conexion); 
		} 

        $html = file_get_contents($url);

        $pos1 = stripos($html, $noseencuentra);
       
        if ($pos1 === false) {
            echo "1";
            global $conexion;
			
		$sql = "INSERT INTO mydiccionario_esnew (palabra) VALUES ( '".$b."')";
              		
		//$result = $conexion->query($sql);
                           
        }
        else
            echo "0";
    }

    $conexion->close();

?>
