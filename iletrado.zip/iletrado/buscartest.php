<?php

header('Content-Type: text/plain; charset=utf-8');

//risa,tema,rima,fan
$buscar = $_POST['palabra'];
$diclang = $_POST['diclanguage'];


echo "1";


       
?>
