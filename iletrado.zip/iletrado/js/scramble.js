//Rosana: No olvidar la posibilidad de convertir en app con phonegap o alternativa
//Personalizar el tablero con idiomas y colores
//Monosilabas y bisilabas no valen
//comprobar que las palabras escaneas son siempre contiguas y no tienen huecos (ok)
//No debe permitir cambiar sino antes ha rellenado las fichas.(ok)
//GAME OVER cuando el saco este vacio y mostrar al ganador con todos los honores
$(document).ready(function() 
{ 	
	var debug=0;	
	var todasLetras = "AAAAAAAAAABBCCDDDEEEEEEEEEEFFGGGHHIIIIIIIIIJKLLLMMMNNNNNNOOOOOOPPQRRRRRSSSSSTTTTTTUUUUUUUVVWWXXYYZ**";
	var letrasEnSaco;
	const numLetras = 7;	
	var c = document.getElementById("tablero");
	var ctx = c.getContext("2d");
	var p = document.getElementById("letrasJugador");
	var pctx = p.getContext("2d");
	var a= document.getElementById("letrasAdversario");
	var actx = a.getContext("2d");
        //var tipojuego = 'adversario';   //acepta dos posibilidades: clasico o adversario
	var imageTablero = new Image();
	var imageTile = new Image();
	var imageTileBig = new Image();
	var letrasjugador=[];
	var puntosjugador=[];
	var visibleletrasjugador=[];
	var letrasadversario=[];
	var puntosadversario=[];
	var visibleletrasadversario=[];	
	var idceldas_ultimajugada = [];
	var ultimajugada='';
	var resumenvarios=[];
	var letras_colocadas=0;
	var indexceldainicio = 112;	
	var maptablero=[];	
	var myWord;
	var myPoints;
	var cambioLetraJug = false;
	var cambioLetraAdv = false;
	
	var iniciado = false;
	var coordinicial =[235,235];
	var registropalabrasjugador = "";
	var registropalabrasadversario = "";
	sessionStorage.setItem("pal_jug_validos", "");
	sessionStorage.setItem("pal_adv_validos", "");
        var x = document.getElementById("x");
	var y = document.getElementById("y");
	var consulta;
	var turnojugada = 'j';   //empieza jugando el jugador, no la máquina (adversario)
	var puntostotalj = 0;
	var puntostotala = 0; 
	var jugadasEliminatoria = 0;
	var sacoVacio = false;
	var findeljuego = false;

	var tipojuego = document.getElementById("gametype").value;
	var diccionariolang = document.getElementById("diccionarylang").value;

	
       	imageTablero.onload = function() {
	      ctx.drawImage(imageTablero, 0, 0);      
	};
	imageTileBig.onload = function() {
	      dibujarLetrasJugadores(); 	    
	};
	imageTablero.src = 'images/scrabble_board.png';	
	imageTile.src = 'images/scrabble_tile_small.png';
	imageTileBig.src = 'images/scrabble_tile.png';
	
	
	//hacemos focus al campo de búsqueda
	$("#busqueda").focus();
	 
    function variasPalabraEnDiccionario(consulta) { 
	                                                                   
	//hace la búsqueda
	$.ajax({
            type: "POST",
            url: "buscar.php",
            data: "palabra="+consulta+"&diclanguage="+diccionariolang,
            dataType: "html",
            beforeSend: function(){
                  //imagen de carga
                  //$("#resultado").html("<p align='center'></p>");
            },
            error: function(){
                  alert("error petición ajax");
            },
            success: function(data){                                                   
			  	if(Number(data) == 1){
					if(turnojugada=='j'){
				
						puntospartialj = Number(sumarPuntosUltimaJugada(idceldas_ultimajugada));
						puntostotalj += puntospartialj;
						registropalabrasjugador = sessionStorage.getItem("pal_jug_validos");
						registropalabrasjugador += consulta + "(" + puntospartialj  + "),"; 
						sessionStorage.setItem("pal_jug_validos", registropalabrasjugador);						
					}
					else{
						puntospartiala = Number(sumarPuntosUltimaJugada(idceldas_ultimajugada));
						puntostotala += puntospartiala;
						registropalabrasadversario = sessionStorage.getItem("pal_adv_validos");
						registropalabrasadversario += consulta + "(" + puntospartiala + "),"; 
						sessionStorage.setItem("pal_adv_validos", registropalabrasadversario);						
					}

	                aceptarUltimaJugada();			
			  	}
			  	else if (Number(data) == 0)
			  		anularUltimaJugada();		                                 
            }
	  }); 
	}

	
   function palabraEnDiccionario() {

    //obtenemos el texto introducido en el campo de búsqueda
	consulta = $("#busqueda").val();
	
	                                                                   
	//hace la búsqueda
	$.ajax({
            type: "POST",
            url: "buscar.php",
            data: "b="+consulta,
            dataType: "html",
            beforeSend: function(){
                  //imagen de carga
                  //$("#resultado").html("<p align='center'></p>");
            },
            error: function(){
                  alert("error petición ajax");
            },
            success: function(data){                                                    
                  //$("#resultado").empty();		  
                  		                                 
            }
	  }); 
	}

	$("#comprobarJugada").click(function(e){

	    if(!tableroSoloLetrasBloqueadas(turnojugada)){
	        document.getElementById('resultado').innerHTML='';

			obtenerUltimaJugada();		
			
			if(debug)		
			 	alert(ultimajugada + "---" + idceldas_ultimajugada); 
			
			variasPalabraEnDiccionario(ultimajugada);
						
	    }
	    else
			alert("Antes de Comprobar la Jugada debe Jugar: " + turnojugada);	
	});

	/*
	$("#comprobarPalabra").click(function(e){
	    document.getElementById('resultado').innerHTML='';		 
		palabraEnDiccionario();	
	});
	*/

	$("#rellenarLetrasju").click(function(e){
		if(turnojugada=='j' && tableroSoloLetrasBloqueadas('j'))
			completarLetrasSaco(turnojugada);
	});

	$("#rellenarLetrasad").click(function(e){
		if(tableroSoloLetrasBloqueadas('a') && (turnojugada=='a'))
			completarLetrasSaco(turnojugada);
	});
        
	$("#cambiarTodasju").click(function(e){
		if(tableroSoloLetrasBloqueadas('j') && (turnojugada=='j'))
			cambiarLetras('j');		    
	});

	$("#cambiarLetraju").click(function(e){
		if(tableroSoloLetrasBloqueadas('j') && (turnojugada=='j'))		
			cambioLetraJug = true;		    
	});

	$("#cambiarTodasad").click(function(e){
		if(tableroSoloLetrasBloqueadas('a') && (turnojugada=='a'))
			cambiarLetras('a');		 
	});

	$("#cambiarLetraad").click(function(e){
		if(tableroSoloLetrasBloqueadas('a') && (turnojugada=='a'))
			cambioLetraAdv = true;
	});
       
    $("#obtenerResumen").click(function(e){
		if(debug)		
		 	alert(resumenvarios);
		mostrarlistaJugadas();
	});

	$("#rendirse").click(function(e){
		var puntos_jugador, puntos_adversario;
		puntos_jugador = 0;
		puntos_adversario = 0;
		var total_puntos = 0;
		if(tipojuego == 'adversario'){
			if(turnojugada=='j'){
				puntos_jugador = Number(sessionStorage.getItem("scorejugador"))*2;					
				puntos_adversario = Number(sessionStorage.getItem("scoreadversario"));
				total_puntos =  puntos_adversario+puntos_jugador;
				sessionStorage.setItem("scoreadversario", total_puntos);	
			}
			else{
				puntos_adversario = Number(sessionStorage.getItem("scoreadversario"))*2;	
				puntos_jugador = Number(sessionStorage.getItem("scorejugador"));
				total_puntos =  puntos_adversario + puntos_jugador;
				sessionStorage.setItem("scorejugador", total_puntos);	

			}
		}
		
		mostrarScores();
	});
	                   

	function iniciarMapaTablero() {
		// Este bucle crea un mapeo de inicio
		var temp;
                var contador = 0;
		for(y=0; y<15; y++){
			for(x=0; x<15; x++){   
			    temp={  
				id: contador,
				coordx: (x*33)+4,
				coordy: (y*33)+4,
  				isVisible: false,
				letra: '',
				puntos: -1,
				multiplicador: 1,
				ambitomultiplicador: 'letra',
				bloqueado:false,  //true: la letra ya a sido validada y forma parte de una palabra ganada
				sieteletrasposition:-1,
				turno:'',
				
			   }	
			   maptablero.push(temp);
			   contador++;
			}
		}
		
		identificarMultiplicadores();
		sessionStorage.setItem("coord_base_x", coordinicial[0]);
		sessionStorage.setItem("coord_base_y", coordinicial[1]);
	}

	


	//Devuelve los pixeles de coordenadas según los pixels que se encuentran bajo el cursor de ratón
	 HTMLCanvasElement.prototype.relativeCoords = function(event) {
	     var x,y;
	     var rect = this.getBoundingClientRect();
	     x = event.clientX - rect.left;
	     y = event.clientY - rect.top;
	     var width = rect.right - rect.left;
	     if(this.width!=width) {
		    var height = rect.bottom - rect.top;
		    x = x*(this.width/width);
		    y = y*(this.width/height);
	     } 
	     //Devuelve un array con las coordenadas
	     return [x,y];
	}


        

	function obtenerIdCelda(coordenadabase) {
	   var i;
	   for(i=0; i<225; i++){		
	    if((Number(maptablero[i].coordx) == Number(coordenadabase[0])) && (Number(maptablero[i].coordy) == Number(coordenadabase[1]))){
		return maptablero[i].id;
		break;
	     }	
	    }	
	}

	function obtenerIdLetra(coordenada) {  //8,107  78,107  148,107    suma 70 izq y suma 64 dcha
		var index=-1;
		var i, leftx, rightx;
		if((Number(coordenada[1])>=107)&&(Number(coordenada[1])<=420))  {   
		    for(i=0;i<7;i++){
			leftx=(i*70)+8;
			rightx = leftx + 64;
			if((Number(coordenada[0])>=Number(leftx))&&(Number(coordenada[0])<=Number(rightx)))
			    index=i;		
		    }			
		} 
		return index;    	
	}

	function obtenerCoordenadaBase(coordenadas, idcanvas) {
	    var coordx = Math.floor(coordenadas[0]);
	    var coordy = Math.floor(coordenadas[1]);
	    var ptocoord,jptocoord,aptocoord;	    
	    if (idcanvas == 'c'){
		    ptocoord= new Array(15);

	 	    for (i=0;i<=15;i++)
			ptocoord[i] = (i*33)+4;
		    for (i=0;i<=15;i++)
			if(ptocoord[i]>coordx){
				coordx = ptocoord[i-1];
				break;		
		    	}
		    for (j=0;j<=15;j++)
			if(ptocoord[j]>coordy){
				coordy = ptocoord[j-1];
				break;		
		    	}
	    }
	    return [coordx,coordy]; 
	
	}

	function identificarMultiplicadores(){
		var indexdobleletra =[3,11,36,38,45,52,59,92,96,98,102,108,116,122,126,128,132,165,172,179,186,188,213,221];
		var indexdoblepalabra =[16,28,32,42,48,56,64,70,154,160,168,176,182,192,196,208];
		var indextripleletra =[20,24,76,80,84,88,136,140,144,148,200,204];
		var indextriplepalabra =[0,7,14,105,119,210,217,224];
		var i;
		for(i=0;i<indexdobleletra.length;i++){
			maptablero[indexdobleletra[i]].multiplicador=2;
			maptablero[indexdobleletra[i]].ambitomultiplicador='letra';
		}
		for(i=0;i<indexdoblepalabra.length;i++){
			maptablero[indexdoblepalabra[i]].multiplicador=2;
			maptablero[indexdoblepalabra[i]].ambitomultiplicador='palabra';
		}
		for(i=0;i<indextripleletra.length;i++){
			maptablero[indextripleletra[i]].multiplicador=3;
			maptablero[indextripleletra[i]].ambitomultiplicador='letra';
		}
		for(i=0;i<indextriplepalabra.length;i++){
			maptablero[indextriplepalabra[i]].multiplicador=3;
			maptablero[indextriplepalabra[i]].ambitomultiplicador='palabra';
		}
	}

	function refrescarMapaTablero() {
		// Este bucle crea un mapeo de inicio
		var xcoord;
		var ycoord;
		var xcoord_letra;
		var ycoord_letra;
		var xcoord_puntos;
		var ycoord_puntos;
		var letra;
		var puntos;
		var temp;
                var contador = 0;
		ctx.clearRect(0,0,c.width,c.height);
		ctx.drawImage(imageTablero, 0, 0);
	 
		for(y=0; y<15; y++){
			for(x=0; x<15; x++){  
				if(maptablero[contador].isVisible){ 
					letra= maptablero[contador].letra;
					puntos= maptablero[contador].puntos;
					xcoord= Number(maptablero[contador].coordx);
					ycoord= Number(maptablero[contador].coordy);
					xcoord_letra = xcoord + 8;
					ycoord_letra = ycoord+ 22;
					xcoord_puntos = xcoord + 20;
					ycoord_puntos = ycoord + 22;

					ctx.drawImage(imageTile, xcoord, ycoord);
					ctx.font="20px 'News Gothic', sans-serif";
					ctx.fillText(letra,xcoord_letra,ycoord_letra); 
					ctx.font="11px 'News Gothic', sans-serif";
					ctx.fillText(puntos, xcoord_puntos,ycoord_puntos);

				}
				contador++;		
			}
		}	
	}


	function aceptarUltimaJugada() {		
		var contador = 0;
		for(y=0; y<15; y++){
			for(x=0; x<15; x++){   
				if(maptablero[contador].isVisible && (!maptablero[contador].bloqueado)){                        
					maptablero[contador].bloqueado = true;		
		    		}		
				contador++;	
			}	
		} 
		document.getElementById('tpuntosjugador').innerHTML = puntostotalj;
        sessionStorage.setItem("scorejugador", puntostotalj);
        if(tipojuego == 'adversario'){
	        document.getElementById('tpuntosadversario').innerHTML = puntostotala;
			sessionStorage.setItem("scoreadversario", puntostotala);
		}
		if(turnojugada=='j'){
			if(tipojuego == 'adversario'){
				turnojugada = 'a';
				mostrarTurnoActual('a');
			}
		}
		else{
			turnojugada = 'j';
			mostrarTurnoActual('j');
		}
		//El juego acaba cuando el saco queda vacio y se juega dos jugadas eliminatorias (una para cada jugador), o en caso de juego clasico 2 jugadas el mismo jugador
		if(sacoVacio && jugadasEliminatoria<2)
			jugadasEliminatoria++;

		if(jugadasEliminatoria >= 2){
			finJuego();
		}
	}


	function anularUltimaJugada() {		
		var contador = 0;
		for(y=0; y<15; y++){
			for(x=0; x<15; x++){   
				if(maptablero[contador].isVisible && (!maptablero[contador].bloqueado)){                        
					if(maptablero[contador].turno == 'j')
				              visibleletrasjugador[maptablero[contador].sieteletrasposition] = true;
					else if (maptablero[contador].turno == 'a')
			        	      visibleletrasadversario[maptablero[contador].sieteletrasposition] = true;
			
					maptablero[contador].isVisible=false;
					maptablero[contador].letra = '';
					maptablero[contador].punto = -1;
					maptablero[contador].turno = '';			
							
		    		}		
				contador++;	
			}	
		} 
		refrescarMapaTablero();
		dibujarLetrasJugadores();
		if(turnojugada=='j'){
			if(tipojuego == 'adversario'){
				turnojugada = 'a';
				mostrarTurnoActual('a');
			}
		}
		else{
			turnojugada = 'j';
			mostrarTurnoActual('j');
		}

		if(sacoVacio && jugadasEliminatoria<2)
			jugadasEliminatoria++;

		if(jugadasEliminatoria >= 2){
			finJuego();
		}
	}

	function finJuego(){
		document.getElementById("comprobarJugada").style.display="none";		
		mostrarScores();	

	}

	function mostrarScores(){
		var resumenjug, resumenadv;
		var puntosfinalesjug, puntosfinalesadv;

		puntosfinalesjug = 0;
		puntosfinalesadv = 0;

		puntosfinalesjug = Number(sessionStorage.getItem("scorejugador")) - Number(sumarLetrasRestantes('j'));
		puntosfinalesadv = Number(sessionStorage.getItem("scoreadversario")) - Number(sumarLetrasRestantes('a'));
		
		resumenjug= "Jugador (Score: " + puntosfinalesjug + ") Puntos por Jugadas:" + sessionStorage.getItem("pal_jug_validos") + " Penalización Letras Restantes: " + sumarLetrasRestantes('j') ;
		if(tipojuego == 'adversario'){
			resumenadv= "Adversario (Score: " + puntosfinalesadv + ") Puntos por Jugadas:" + sessionStorage.getItem("pal_adv_validos") + " Penalización Letras Restantes: " + sumarLetrasRestantes('a') ;;
			alert(resumenjug + "  VERSUS  " + resumenadv);
		}
		else
			alert(resumenjug);
		

	}

	function mostrarlistaJugadas(){
		var resumenjug, resumenadv;	
		
		resumenjug= "Jugador (Score: " + puntostotalj + ") Puntos por Jugadas:" + sessionStorage.getItem("pal_jug_validos");
		if(tipojuego == 'adversario'){
			resumenadv= "Adversario (Score: " + puntostotala + ") Puntos por Jugadas:" + sessionStorage.getItem("pal_adv_validos");
			alert("LISTA DE JUGADAS VALIDADAS:" + resumenjug + "  VERSUS  " + resumenadv);
		}
		else
			alert(resumenjug);
	}


	function sumarLetrasRestantes(turno='j'){   
		var i=0;
		var contadoresto = 0;			
		if(turno=='j'){			
			
			while (i < letrasjugador.length) {
				if(visibleletrasjugador[i]){
					contadoresto += puntosjugador[i];
				}
				i++;
			}			
		}
		else{
			
			while (i < letrasadversario.length) {
				if(visibleletrasadversario[i]){
					contadoresto += puntosadversario[i];
				}
				i++;
			}
		}

		return contadoresto;
	}

	function sumarPuntosUltimaJugada(idceldas){
		var letra;
		var puntos;
		var temppuntospalabras = 0;
		var multiplipuntospalabras = 0;
		var totalpuntospalabras = 0;
                var multip, ambitomultip, letra;

                var i = 0;
		
		
		while (i < idceldas.length) {
			letra = maptablero[Number(idceldas[i])].letra;
			puntos = maptablero[Number(idceldas[i])].puntos;
			multip = maptablero[Number(idceldas[i])].multiplicador;
			ambitomultip = maptablero[Number(idceldas[i])].ambitomultiplicador;
			if ((ambitomultip == 'letra') && (multip > 1)){					
			   temppuntospalabras += puntos*multip;
			   if (debug)
			    alert(letra + "--" + "---" + puntos + "---" + multip + "---" + multiplipuntospalabras);
			}
			else{
		           temppuntospalabras += puntos;
			   if (debug)
			    alert(letra + "---" + puntos + "---" + temppuntospalabras);
			}
		        i++;
		}
		if(debug)
			alert("puntos con/sin multi (letras): " + temppuntospalabras);

		i=0;
		while (i < idceldas.length) {
			letra = maptablero[Number(idceldas[i])].letra;
			multip = maptablero[Number(idceldas[i])].multiplicador;
			ambitomultip = maptablero[Number(idceldas[i])].ambitomultiplicador;
			
			
			if ((ambitomultip == 'palabra') && (multip > 1)){					
			   multiplipuntospalabras += temppuntospalabras*multip;
			if (debug)
			     alert(letra + "--" + temppuntospalabras + "---" + multip + "---" + multiplipuntospalabras);
		        }  
			i++;
		}
		if(debug)
			alert("puntos con multip (ambito palabras): " + multiplipuntospalabras);
		totalpuntospalabras = temppuntospalabras + multiplipuntospalabras;
		return totalpuntospalabras;
	
	 
	}


	function obtenerUltimaJugada() {		
		var contador = 0;
		var i;
		var id;
		var temp_palabra = '';
		var temp_palabra_id = '';
		var temp_idceldas = [];
		var hayletraconjugada = false;
		var seguirleyendoletra = true;
		var haybloqueados = false;
		var hayhueco = false;
		var id_anterior;
		ultimajugada = '';
		idceldas_ultimajugada = [];
		//HORIZONTAL
		for(y=0; y<15; y++){ 
			for(x=0; x<15; x++){   
				if(maptablero[contador].isVisible){                        
					//si al escanear ya alguna letra hubiera en una fila un hueco (posición anterior) se invalida esa palabra temporal
					if(temp_palabra != '' && !maptablero[contador-1].isVisible && !hayletraconjugada){	
						temp_palabra = '';
						temp_palabra_id = '';
					}
					
					if(temp_palabra != '' && !maptablero[contador-1].isVisible && hayletraconjugada)	
						seguirleyendoletra = false;

					/*if(temp_palabra != '' && !maptablero[contador-1].isVisible && !haybloqueados)	
						hayhueco = true;
					*/
					
					if(seguirleyendoletra){
					        temp_palabra += maptablero[contador].letra;
						temp_palabra_id += contador + ","; 
						temp_idceldas.push(contador);
					}

					if(!maptablero[contador].bloqueado)
						hayletraconjugada = true;
					else
						haybloqueados = true;		
		    		}						
				contador++;
				if(contador%15==0 && temp_palabra!='')  //chequea palabras por fila (multiplo de 15) horizontal
				{   
					 
					 if(temp_palabra.length >= 2 && hayletraconjugada && !hayhueco){
						 //document.getElementById('resultado').innerHTML += "<br>" + temp_palabra;
						 if (debug)
						     document.getElementById('resultado').innerHTML += " ( " + temp_palabra_id + " )";
						 if(ultimajugada=='')//primera palabra no lleva ,
						 	ultimajugada+=temp_palabra;
						 
						 else
							ultimajugada+=","+temp_palabra;
						

						i=0;					
						while (i < temp_idceldas.length){				         								idceldas_ultimajugada.push(temp_idceldas[i]);			
							i++;
						}	
						
						
					 }
					 temp_palabra = '';
					 temp_palabra_id = '';
					 temp_idceldas =[];
				         hayletraconjugada = false;
				         hayhueco = false;
					 seguirleyendoletra = true;
					 haybloqueados = false;		   
				}
				
			}	
		} 
		
		//VERTICAL
		temp_palabra = '';
		temp_palabra_id = '';
		temp_idceldas = [];
		hayletraconjugada = false;
		hayhueco = false;		
		seguirleyendoletra = true;
                haybloqueados = false;

		for(x=0; x<15; x++){ 
			for(y=0; y<15; y++){ 
				id=(y*15)+x; 
				
				if(maptablero[id].isVisible){                        
					//si al escanear ya alguna letra hubiera en una columna un hueco (la casilla inmediata de arriba se invalida esa palabra temporal
					if(temp_palabra != '' && !maptablero[id-15].isVisible && !hayletraconjugada){
						temp_palabra = '';
						temp_palabra_id = '';
				        }
					
					if(temp_palabra != '' && !maptablero[id-15].isVisible && hayletraconjugada)
						seguirleyendoletra = false;
					
					/*if(temp_palabra != '' && !maptablero[contador-1].isVisible && !haybloqueados)	
						hayhueco = true;
					*/
					if(seguirleyendoletra){
					   temp_palabra += maptablero[id].letra;
					   temp_palabra_id += id + ","; 
					   temp_idceldas.push(id);
					}
                                        

					if(!maptablero[id].bloqueado)
						hayletraconjugada = true;
					else
						haybloqueados = true;		
		    		}							
			}
			if(temp_palabra !='')
			{   
				 seguirleyendoletra = true;
				 if(temp_palabra.length >= 2 && hayletraconjugada && !hayhueco){ 
					 document.getElementById('resultado').innerHTML += "<br>" + temp_palabra;
				         if (debug)
					    document.getElementById('resultado').innerHTML += " ( " + temp_palabra_id + " )";
					if(ultimajugada=='') //primera palabra no lleva ,
						 ultimajugada+=temp_palabra;
				        else
						 ultimajugada+=","+temp_palabra;
					
					i=0;					
					while (i < temp_idceldas.length){				         							idceldas_ultimajugada.push(temp_idceldas[i]);
						i++;
					}
					
					
				 }

			         temp_palabra = '';
				 temp_palabra_id = '';
				 temp_idceldas = [];
				 hayletraconjugada = false;
				 hayhueco = false;
			         seguirleyendoletra = true;
			         haybloqueados = false;		 				   
			}
				
		} 
		if(debug)
			alert(idceldas_ultimajugada);

	}


	function remezclarLetras(word) {
	    return word.split('').sort(function(){ return Math.random() - 0.5 }).join('');
	}


	function dibujarLetrasJugadores() {  
	    var xcoord;
	    var ycoord;
	    var xcoord_letra;
	    var ycoord_letra;
	    var xcoord_puntos;
	    var ycoord_puntos; 
	    var i=0;
	    
	    pctx.clearRect(0,0,p.width,p.height);
	    actx.clearRect(0,0,a.width,a.height);
            while (i < letrasjugador.length) {
                xcoord = 8+70*i;
		ycoord = 20;		
		xcoord_letra = Number(xcoord) + 20;
		ycoord_letra = Number(ycoord) + 50;
		xcoord_puntos = Number(xcoord) + 46;
		ycoord_puntos = Number(ycoord) + 50;
		
		if(tipojuego == 'clasico')
                {   
			document.getElementById("adversario").className = "adversario_off";
			document.getElementById("paneladversario").className = "adversario_off";

			  
			if(visibleletrasjugador[i]){
				pctx.drawImage(imageTileBig, xcoord,ycoord);
				pctx.font="45px 'News Gothic', sans-serif";
				pctx.fillText(letrasjugador[i],xcoord_letra,ycoord_letra);  
				pctx.font="15px 'News Gothic', sans-serif";
				pctx.fillText(puntosjugador[i],xcoord_puntos,ycoord_puntos); 
				
			}
			i++;
		}
		else{ 
			document.getElementById("adversario").className = "adversario_on";	
			if(visibleletrasjugador[i]){  
				pctx.drawImage(imageTileBig, xcoord,ycoord);
				pctx.font="45px 'News Gothic', sans-serif";
				pctx.fillText(letrasjugador[i],xcoord_letra,ycoord_letra);  
				pctx.font="15px 'News Gothic', sans-serif";
				pctx.fillText(puntosjugador[i],xcoord_puntos,ycoord_puntos);
			}
			if(visibleletrasadversario[i]){		
				actx.drawImage(imageTileBig, xcoord,ycoord);
				actx.font="45px 'News Gothic', sans-serif";
				actx.fillText(letrasadversario[i],xcoord_letra,ycoord_letra);  
				actx.font="15px 'News Gothic', sans-serif";
				actx.fillText(puntosadversario[i],xcoord_puntos,ycoord_puntos); 
				
			} 
			i++;			
		}
		                             
	    }
	
	}


    function tableroSoloLetrasBloqueadas(turno = 'j')
	{     
		var contador = 0;
		for(y=0; y<15; y++){
			for(x=0; x<15; x++){   
				if (maptablero[contador].isVisible && maptablero[contador].turno == turno && !maptablero[contador].bloqueado){                        
					return false;		
		    		}		
				contador++;	
			}	
		} 
		return true;
	}
        //después de una jugada con éxito rellenar los huecos hasta completar un total de 7 letras (normalm. debe ser automático)
    
    
    
    function completarLetrasSaco(turno='j'){   
		var i=0;
		var letra, puntos, mezclado;		
				
		if(turno=='j'){	
			
			
			while (i < letrasjugador.length) {
				if(!visibleletrasjugador[i] && letrasEnSaco.length>0){
					mezclado = remezclarLetras(letrasEnSaco);
					letra = mezclado.substring(0,1);
					letrasEnSaco = mezclado.substring(1);
					letrasjugador[i] = letra;
					puntosjugador[i] = obtenerPuntosLetra(letra);
					visibleletrasjugador[i] = true;
				}
				i++;
			}
			
		}
		else{
			
			while (i < letrasadversario.length) {
				if(!visibleletrasadversario[i] && letrasEnSaco.length>0){
					mezclado = remezclarLetras(letrasEnSaco);
					letra = mezclado.substring(0,1);
					letrasEnSaco = mezclado.substring(1);
					letrasadversario[i] = letra;
					puntosadversario[i] = obtenerPuntosLetra(letra);
					visibleletrasadversario[i] = true;
				}
				i++;
			}
		}
		dibujarLetrasJugadores();		
 		mostrarLetrasEnSaco();
 		mostrarNumLetrasEnSaco();
 		if(letrasEnSaco.length == 0){
			sacoVacio = true;
			document.getElementById("rellenarLetrasju").style.display="none";
			document.getElementById("cambiarLetrasju").style.display="none";
			document.getElementById("rellenarLetrasad").style.display="none";
			document.getElementById("cambiarLetrasad").style.display="none";
					
		}
	}

	function cambiarLetras(turno='j'){   
		var i=0;
		var letra, puntos, mezclado;	
		
		if(turno=='j'){
			while (i < letrasjugador.length) {				
					if(!visibleletrasjugador[i])
						break;
					i++;
			}
			if(i < numLetras)
				alert("No puede solicitar un cambio de letras sin haber antes rellenado");
			else{
				i=0;
				//Devolver las letras actuales al saco y rellenar de nuevo			
				while (i < letrasjugador.length) {				
					visibleletrasjugador[i] = false;
					letrasEnSaco += letrasjugador[i];
					i++;
				}
				completarLetrasSaco(turno='j');
				if(tipojuego == 'adversario'){
					turnojugada ='a';
					mostrarTurnoActual('a');
				}
			}
		}
		else{
			while (i < letrasadversario.length) {				
					if(!visibleletrasadversario[i])
						break;
					i++;
			}
			if(i < numLetras)			
				alert("No puede solicitar un cambio de letras sin haber antes rellenado");
			else{
				i=0;				
				//Devolver las letras actuales al saco y rellenar de nuevo
				while (i < letrasadversario.length) {						
					visibleletrasadversario[i] = false;
					letrasEnSaco += letrasadversario[i];
					i++;
				}
				completarLetrasSaco(turno='a');
				turnojugada ='j';
				mostrarTurnoActual('j');
			}
		}
		dibujarLetrasJugadores();		
 		mostrarLetrasEnSaco();
	}

    function cambiarUnaLetra(indexletra){   

    	//MODIFICAR EL CODIGO PARA QUE CAMBIE UNA SOLA LETRA
    	var i=0;
		var letra, puntos, mezclado;
	
		if(turnojugada=='j'){
			cambioLetraJug = false;
		
			while (i < letrasjugador.length) {				
					if(!visibleletrasjugador[i])
						break;
					i++;
			}
			if(i < numLetras)
				alert("No puede solicitar un cambio de letras sin haber antes rellenado");
			else{
				i=0;
				//Devolver la letra seleccionada al saco y obtener una nueva			
								
				visibleletrasjugador[indexletra] = false;
				letrasEnSaco += letrasjugador[indexletra];

				if(!visibleletrasjugador[indexletra] && letrasEnSaco.length>0){
					mezclado = remezclarLetras(letrasEnSaco);
					letra = mezclado.substring(0,1);
					letrasEnSaco = mezclado.substring(1);
					letrasjugador[indexletra] = letra;
					puntosjugador[indexletra] = obtenerPuntosLetra(letra);
					visibleletrasjugador[indexletra] = true;
				}
				
				if(tipojuego == 'adversario'){
					turnojugada ='a';
					mostrarTurnoActual('a');
				}
			}
		}
		else{
			cambioLetraAdv = false;
			while (i < letrasadversario.length) {				
					if(!visibleletrasadversario[i])
						break;
					i++;
			}
			if(i < numLetras)
				alert("No puede solicitar un cambio de letras sin haber antes rellenado");
			else{
				i=0;
				//Devolver la letra seleccionada al saco y obtener una nueva			
								
				visibleletrasadversario[indexletra] = false;
				letrasEnSaco += letrasadversario[indexletra];

				if(!visibleletrasadversario[indexletra] && letrasEnSaco.length>0){
					mezclado = remezclarLetras(letrasEnSaco);
					letra = mezclado.substring(0,1);
					letrasEnSaco = mezclado.substring(1);
					letrasadversario[indexletra] = letra;
					puntosadversario[indexletra] = obtenerPuntosLetra(letra);
					visibleletrasadversario[indexletra] = true;
				}
				
				if(tipojuego == 'adversario'){
					turnojugada ='j';
					mostrarTurnoActual('j');
				}
			}
		}	
		
		dibujarLetrasJugadores();		
 		mostrarLetrasEnSaco();
		
	}   

	function obtenerPuntosLetra(letra){
		if (letra == 'A' || letra == 'E' || letra == 'I' || letra == 'L'|| letra == 'N' || letra == 'O' || letra == 'R' || letra == 'S' || letra == 'T'|| letra == 'U')
			myPoints = 1;
		else if (letra == 'D' || letra == 'G')
			myPoints = 2;
		else if (letra == 'B' || letra == 'C' || letra == 'M' || letra == 'P')
			myPoints = 3;
		else if (letra == 'F' || letra == 'H' || letra == 'V' || letra == 'W'||  letra == 'X' || letra == 'Y')
			myPoints = 4;
		else if (letra == 'K')
			myPoints = 5;
		else if (letra == 'J')
			myPoints = 8;
		else if (letra == 'Q' || letra == 'Z')
			myPoints = 10;
		else 
			myPoints = 1;

		return myPoints;
		
	}

	function asignarLetras(word) {
	    var html = "";
	    var size = 0;
	    if(tipojuego == 'clasico'){
	    	if (word.length <=numLetras)
			size = word.length;
	    	else
			size = numLetras;
	    }
	    else{  //juego con adversario
		if (word.length <= numLetras*2)
			size = word.length;
	    	else
			size = numLetras*2;	    
	    }
	   
	    for (var i = 0; i < size; i++) {
		myPoints = obtenerPuntosLetra(word[i]);
		//elimina del saco las letras escogida al azar
		var index_letra = Number(letrasEnSaco.indexOf(word[i]));  
		letrasEnSaco = letrasEnSaco.substring(0,index_letra) + letrasEnSaco.substring(index_letra+1);
		
		if(tipojuego == 'clasico'){
			
			letrasjugador.push(word[i]);
			puntosjugador.push(myPoints);
			visibleletrasjugador.push(true);
		}
		else{
			if(i%2==0){
				letrasjugador.push(word[i]);
				puntosjugador.push(myPoints);
				visibleletrasjugador.push(true);
			}else{
				letrasadversario.push(word[i]);
				puntosadversario.push(myPoints);
				visibleletrasadversario.push(true);
			}
		}		
	    }		
	}


	function MostrarInformacionDebug() { 
        //Hacer visible la información de debug solo si la variable debug == 1 que se define en la definión de variables
		if(debug){
			document.getElementById("debug1").className = "debug_on";
			document.getElementById("debug2").className = "debug_on";
			//document.getElementById("debug3").className = "debug_on";
		}
		else{
			document.getElementById("debug1").className = "debug_off";
			document.getElementById("debug2").className = "debug_off";
			//document.getElementById("debug3").className = "debug_off";
		}
	}


	function mostrarLetrasEnSaco() {
		var letrasiguiente;
		var html=""
		if(true){		
			for (var i = 0; i < letrasEnSaco.length; i++) {
				letrasiguiente = letrasEnSaco.substring(i,i+1);
				html += '<li class="tile"><span class="sbbletra">' + letrasiguiente + '</span><span class="sbbpuntos">' + obtenerPuntosLetra(letrasiguiente) + '</span></li>';		   
			
			}
		}
		$('.word').html(html);
	}

	function extraerLetrasSaco() {
	   
	    var mezclado = remezclarLetras(letrasEnSaco);
	    var i=0;
	    while (i<100) {
		mezclado = remezclarLetras(mezclado);
		i++;
	    }
	    while (mezclado == letrasEnSaco){
		mezclado = remezclarLetras(mezclado);
	    }
	    asignarLetras(mezclado);
	}


	function llenarLetraEnSaco(){
	    var temp;
	    temp = todasLetras;
	    letrasEnSaco= temp;
	    //letrasEnSaco = "ABCDEFGHIJKLMNOPQRSTUVXYZ";  //BORRAR
	}

	function mostrarTurnoActual(turno = 'j'){
	    document.getElementById('turnoActual').innerHTML = "";
	    if (turno == 'j'){
	    	document.getElementById('turnoActual').innerHTML = "JUGADOR";
	    	document.getElementById("paneljugador").className = "scorebackground_on";
	    	document.getElementById("paneladversario").className = "scorebackground_off";
	    	document.getElementById("fondoletrasju").className = "fondoletrasbackground_on";
	    	document.getElementById("fondoletrasad").className = "fondoletrasbackground_off";

	    }
	    else{
	    	document.getElementById('turnoActual').innerHTML = "ADVERSARIO";
	    	document.getElementById("paneljugador").className = "scorebackground_off";
	    	document.getElementById("paneladversario").className = "scorebackground_on";
	    	document.getElementById("fondoletrasju").className = "fondoletrasbackground_off";
	    	document.getElementById("fondoletrasad").className = "fondoletrasbackground_on";
	    }
	
	
	}

	function mostrarNumLetrasEnSaco(){
	    //document.getElementById('turnoActual').innerHTML = letrasEnSaco.length;
	    
	
	}
		
        

	function iniciarJuego() {
	    mostrarTurnoActual();
	    llenarLetraEnSaco();
	    iniciarMapaTablero();
            extraerLetrasSaco();
	    mostrarLetrasEnSaco();
	    //mostrarNumLetrasEnSaco();
	    MostrarInformacionDebug();
             
	}


	$(function(){    
	    iniciarJuego();
	});



c.addEventListener("mousemove", function(event) {   
	if(debug){
		var coordsc = c.relativeCoords(event);
		document.getElementById('x').innerHTML = Math.floor(coordsc[0]);
		document.getElementById('y').innerHTML = Math.floor(coordsc[1]);
		var coordsbase = obtenerCoordenadaBase(coordsc, 'c');
		var coordx= coordsbase[0];
		var coordy = coordsbase[1];
		var id = obtenerIdCelda(coordsbase);
		 if(id){
		  document.getElementById('info').innerHTML = "ESVISIBLE: " + maptablero[id].isVisible +", BLOQUEADO: " + maptablero[id].bloqueado + " Identificador: " + id + ", CoordX: " + coordx + ", CoordY: " + coordy + ", LETRA: " + maptablero[id].letra + ", PUNTOS: " + maptablero[id].puntos +  ", Multiplicador: " + maptablero[id].multiplicador + ", Ambito: " + maptablero[id].ambitomultiplicador + ", TURNO: " + maptablero[id].turno;
		 } 
	}
	});

p.addEventListener("mousemove", function(event) {   
        if(debug){		
		var coordsa = p.relativeCoords(event);
		document.getElementById('px').innerHTML = Math.floor(coordsa[0]);
		document.getElementById('py').innerHTML = Math.floor(coordsa[1]);
        }
	});

a.addEventListener("mousemove", function(event) {   
	if(debug){
		var coordsa = a.relativeCoords(event);
		document.getElementById('ax').innerHTML = Math.floor(coordsa[0]);
		document.getElementById('ay').innerHTML = Math.floor(coordsa[1]);
	}
	});


c.addEventListener("dblclick", function(event) {
		var coords = c.relativeCoords(event);
		var coordsbase = obtenerCoordenadaBase(coords, 'c');
		var coordx= coordsbase[0];
		var coordy = coordsbase[1];
		var id = obtenerIdCelda(coordsbase);	
		resumenvarios.push(id);  	              
		
		
	});

c.addEventListener("click", function(event) {
		var coords = c.relativeCoords(event);	  
		var coordsbase = obtenerCoordenadaBase(coords, 'c');
		var id = obtenerIdCelda(coordsbase);
		var coordx= coordsbase[0];
		var coordy = coordsbase[1];
		if(!maptablero[id].isVisible){ 
			refrescarMapaTablero();
			ctx.strokeStyle ='black';
            		ctx.strokeRect(coordx,coordy,30, 30);
		}
		
		if(maptablero[indexceldainicio].isVisible){ //solo se introduce nueva letra si se ha empezado por la celda estrella
		
			sessionStorage.setItem("coord_base_x", coordx);
			sessionStorage.setItem("coord_base_y", coordy);
		}
		else{
			refrescarMapaTablero();
			ctx.strokeStyle ='black';
            		ctx.strokeRect(coordinicial[0],coordinicial[1],30, 30);
		}
		if(maptablero[id].isVisible && !(maptablero[id].bloqueado)){ 
			if(maptablero[id].turno == 'j')
				visibleletrasjugador[maptablero[id].sieteletrasposition] = true;
			else if (maptablero[id].turno == 'a')
			        visibleletrasadversario[maptablero[id].sieteletrasposition] = true;		
			maptablero[id].isVisible=false;
			maptablero[id].letra = '';
			maptablero[id].punto = -1;
			maptablero[id].turno = '';			
			refrescarMapaTablero();
			dibujarLetrasJugadores();	  				
		} 
	});

p.addEventListener("click", function(event) {
	if(turnojugada=='j'){

		var coords = p.relativeCoords(event);	  
		var id = obtenerIdLetra(coords);

		if(cambioLetraJug == true){
			cambiarUnaLetra(id);
			
		}
		else{

			if(!maptablero[indexceldainicio].isVisible){ //solo se introduce nueva letra si se ha empezado por la celda estrella
			
				sessionStorage.setItem("coord_base_x", coordinicial[0]);
				sessionStorage.setItem("coord_base_y", coordinicial[1]);
			}		

							
			var letra ="";		
			var puntos;
			var coordsel=[];
			coordsel[0] = Number(sessionStorage.getItem("coord_base_x"));
			coordsel[1] = Number(sessionStorage.getItem("coord_base_y"));
			var xcoordsel_letra = Number(coordsel[0] ) + 8;
			var ycoordsel_letra = Number(coordsel[1] ) + 22;
			var xcoordsel_puntos = Number(coordsel[0] ) + 20;
			var ycoordsel_puntos = Number(coordsel[1] ) + 22;
			var id_celda = obtenerIdCelda(coordsel);
			if(id != -1 && maptablero[id_celda].isVisible==false){  //si se hace click sobre alguna de las 7 letras	
				if(letrasjugador[id] == '*'){
				letra =prompt("Introduce la letra que quiere suplantar a la tecla comodín");
				letra = letra.toUpperCase();
				puntos = 1;
				}
				else{
					letra = letrasjugador[id];
					puntos = puntosjugador[id];
				}
				ctx.drawImage(imageTile, coordsel[0] ,coordsel[1] );
				ctx.font="20px 'News Gothic', sans-serif";
				ctx.fillText(letra,xcoordsel_letra,ycoordsel_letra); 
				ctx.font="11px 'News Gothic', sans-serif";
				ctx.fillText(puntos, xcoordsel_puntos,ycoordsel_puntos);
				
				
				//ultimajugada.push(Number(id_celda));
				maptablero[id_celda].isVisible=true;
				maptablero[id_celda].letra=letra;
				maptablero[id_celda].puntos=puntos;
				maptablero[id_celda].sieteletrasposition=id;
				maptablero[id_celda].turno='j';
				visibleletrasjugador[id] = false;
				dibujarLetrasJugadores();
			}
		}
	}
	else
		alert("Ahora toca turno a ADVERSARIO");
});

a.addEventListener("click", function(event) {
	if(turnojugada=='a'){
		var coords = a.relativeCoords(event);	  
		var id = obtenerIdLetra(coords);	
		if(cambioLetraAdv == true){
			cambiarUnaLetra(id);
			
		}
		else{

			if(!maptablero[indexceldainicio].isVisible){ //solo se introduce nueva letra si se ha empezado por la celda estrella
			
				sessionStorage.setItem("coord_base_x", coordinicial[0]);
				sessionStorage.setItem("coord_base_y", coordinicial[1]);
			}				
				
			var letra ="";
			var puntos = "";
			var coordsel=[];
			coordsel[0] = Number(sessionStorage.getItem("coord_base_x"));
			coordsel[1] = Number(sessionStorage.getItem("coord_base_y"));
			var xcoordsel_letra = Number(coordsel[0] ) + 8;
			var ycoordsel_letra = Number(coordsel[1] ) + 22;
			var xcoordsel_puntos = Number(coordsel[0] ) + 20;
			var ycoordsel_puntos = Number(coordsel[1] ) + 22;
			var id_celda = obtenerIdCelda(coordsel);

			//Revisar me he quedado aqui
			if(id != -1 && maptablero[id_celda].isVisible==false){  //si se hace click sobre alguna de las 7 letras
				if(letrasadversario[id] == '*'){
					letra =prompt("Introduce la letra que quiere suplantar a la tecla comodín");
					letra = letra.toUpperCase();
					puntos = 1;
				}
				else{
					letra = letrasadversario[id];
					puntos = puntosadversario[id];
				}
				ctx.drawImage(imageTile, coordsel[0] ,coordsel[1] );
				ctx.font="20px 'News Gothic', sans-serif";
				ctx.fillText(letra,xcoordsel_letra,ycoordsel_letra); 
				ctx.font="11px 'News Gothic', sans-serif";
				ctx.fillText(puntos, xcoordsel_puntos,ycoordsel_puntos);
				
				
				//ultimajugada.push(Number(id_celda));
				maptablero[id_celda].isVisible=true;
				maptablero[id_celda].letra=letra;
				maptablero[id_celda].puntos=puntos;
				maptablero[id_celda].sieteletrasposition=id;
				maptablero[id_celda].turno='a';
				visibleletrasadversario[id] = false;
				dibujarLetrasJugadores();
			}
		}
      }
	  else
		alert("Ahora toca turno a JUGADOR");
	});
});



