	var dictionary = [
	    /*"TIGER",
	    "LION",
	    "BEAR",*/ 
	    "AAAAAAAAAAAABBCCCC1DDDDDEEEEEEEEEEEEFGGHHIIIIIIJLLLL2MMNNNNNÑOOOOOOOOOPPQRRRRR3SSSSSSTTTTUUUUUVXYZ**"
	];
	var myWord;
	var myLetter;
	var myPoints;


	function scramble(word) {
	    return word.split('').sort(function(){ return Math.random() - 0.5 }).join('');
	}

	function chooseWord() {
	    return dictionary[Math.floor(Math.random() * dictionary.length)];
	}

	function printWord(word) {
	    var html = "";
	    var size = 0;
	    if (word.length <=7)
		size = word.length;
	    else
		size = 7;


	    for (var i = 0; i < size; i++) {
		switch(word[i]){
			case '1':
				myLetter = 'CH';
				break;
			case '2':
				myLetter = 'LL';
				break;
			case '3':
				myLetter = 'RR';
				break;
			default:
				myLetter = word[i];				
		}

		if (myLetter == 'A' || myLetter == 'E' || myLetter == 'I' || myLetter == 'L'|| myLetter == 'N' || myLetter == 'O' || myLetter == 'R' || myLetter == 'S' || myLetter == 'T'|| myLetter == 'U')
			myPoints = 1;
		else if (myLetter == 'D' || myLetter == 'G')
			myPoints = 2;
		else if (myLetter == 'B' || myLetter == 'C' || myLetter == 'M' || myLetter == 'P')
			myPoints = 3;
		else if (myLetter == 'F' || myLetter == 'H' || myLetter == 'V' || myLetter == 'Y')
			myPoints = 4;
		else if (myLetter == 'CH' || myLetter == 'Q')
			myPoints = 5;
		else if (myLetter == 'J' || myLetter == 'LL' || myLetter == 'Ñ' || myLetter == 'RR'|| myLetter == 'X')
			myPoints = 8;
		else if (myLetter == 'Z')
			myPoints = 10;
		else 
			myPoints = '';

					
		html += '<li class="tile">' + myLetter + '<span>' + myPoints + '</span></li>';
	    }
	    $('.word1').html(html);
	}

	function startGame() {
	    myWord = chooseWord();
	    
	    var scrambled = scramble(myWord);
	    var i=0;
	    while (i<50) {
		scrambled = scramble(scrambled);
		i++;
	    }

	    while (scrambled == myWord) {
		scrambled = scramble(scrambled);
	    }
	    
	    printWord(scrambled);
	}

	$(function(){    
	    startGame();
	    
	   /* $('.word1').sortable({
		update: function (e, ui) {
		    console.log(myWord, $('.tile').text());
		    if (myWord === $('.tile').text()) {
			var playAgain = confirm("You win! Play again?");
			if (playAgain) {
			    startGame();
			}                    
		    }
		}
	    }); */ 
	});


