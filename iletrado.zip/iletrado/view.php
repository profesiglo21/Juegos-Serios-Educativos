<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Prints a particular instance of iletrado
 *
 * You can have a rather longer description of the file as well,
 * if you like, and it can span multiple lines.
 *
 * @package    mod_iletrado
 * @copyright  2011 Your Name
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

/// (Replace iletrado with the name of your module and remove this line)

require_once(dirname(dirname(dirname(__FILE__))).'/config.php');
require_once(dirname(__FILE__).'/lib.php');

$id = optional_param('id', 0, PARAM_INT); // course_module ID, or
$n  = optional_param('n', 0, PARAM_INT);  // iletrado instance ID - it should be named as the first character of the module

if ($id) {
    $cm         = get_coursemodule_from_id('iletrado', $id, 0, false, MUST_EXIST);
    $course     = $DB->get_record('course', array('id' => $cm->course), '*', MUST_EXIST);
    $iletrado  = $DB->get_record('iletrado', array('id' => $cm->instance), '*', MUST_EXIST);

 if ($recs = $DB->get_records('iletrado', array('id' => $cm->instance), 'id,gametype,diccionariolang')) {
                foreach ($recs as $rec) {
		    $instanceid = $n;
                    $gametype= $rec->gametype;
		    $diccionarylang= $rec->diccionariolang;  
		         
                }
    }


} elseif ($n) {
    $iletrado  = $DB->get_record('iletrado', array('id' => $n), '*', MUST_EXIST);
    $course     = $DB->get_record('course', array('id' => $iletrado->course), '*', MUST_EXIST);
    $cm         = get_coursemodule_from_instance('iletrado', $iletrado->id, $course->id, false, MUST_EXIST);

   if ($recs = $DB->get_records('iletrado', array('id' => $cm->instance), 'id,gametype,diccionariolang')) {
                foreach ($recs as $rec) {
		    $instanceid = $n;
                    $gametype= $rec->gametype;
		    $diccionarylang= $rec->diccionariolang;  
		         
                }
    }



} else {
    error('You must specify a course_module ID or an instance ID');
}

require_login($course, true, $cm);
$context = context_module::instance($cm->id);

add_to_log($course->id, 'iletrado', 'view', "view.php?id={$cm->id}", $iletrado->name, $cm->id);

/// Print the page header

$PAGE->set_url('/mod/iletrado/view.php', array('id' => $cm->id));
$PAGE->set_title(format_string($iletrado->name));

//inclusion del css for scrambles tiles
$PAGE->requires->css('/mod/iletrado/scramble.css', true);


//inclusion del javascript para las funciones
$PAGE->requires->js('/mod/iletrado/js/jquery.js', true);
$PAGE->requires->js('/mod/iletrado/js/scramble.js', true);


$PAGE->set_heading(format_string($course->fullname));
$PAGE->set_context($context);

// other things you may want to set - remove if not needed
//$PAGE->set_cacheable(false);
//$PAGE->set_focuscontrol('some-html-id');
//$PAGE->add_body_class('iletrado-'.$somevar);

// Output starts here
echo $OUTPUT->header();

if ($iletrado->intro) { // Conditions to show the intro can change to look for own settings or whatever
    echo $OUTPUT->box(format_module_intro('iletrado', $iletrado, $cm->id), 'generalbox mod_introbox', 'iletradointro');
}

// Replace the following lines with you own code



echo $OUTPUT->heading('<input id="gametype" type="hidden" value="'.$gametype.'"><input id="diccionarylang" type="hidden" value="'.$diccionarylang.'">
<div id="contenedor">
	<div id="logo">
		<span class="letralogo" style="margin-top:5px;">I</span>
		<span class="letralogo" style="margin-top:12px;">-</span>
		<span class="letralogo" style="margin-top:8px;">L<span class="numeritologo">1</span></span>
		<span class="letralogo" style="margin-top:5px;">E<span class="numeritologo">1</span></span>
		<span class="letralogo" style="margin-top:12px;">T<span class="numeritologo">1</span></span>
		<span class="letralogo" style="margin-top:8px;">R<span class="numeritologo">1</span></span>
		<span class="letralogo" style="margin-top:5px;">A<span class="numeritologo">1</span></span>
		<span class="letralogo" style="margin-top:12px;">D<span class="numeritologo">2</span></span>
		<span class="letralogo" style="margin-top:8px;">O<span class="numeritologo">1</span></span>
	</div>	
	<br><br>

	<div id="fondotablero">
	    <div id="turnoActual"></div>
		<canvas id="tablero" width="500" height="500"></canvas>

	</div><br>

	<div id="topcontrol" class="jugador_on">
		<input id="comprobarJugada" type="image" src="images/validar_jugada.png" alt="Validar última jugada" title="Validar última jugada"><span class="topcontroltag">Validar Jugada<span>
		<input id="rendirse" type="image" src="images/rendirse.png" title="Rendirse" alt="Rendirse"> Abandonar Juego
		<input id="obtenerResumen" type="image" src="images/boton_lista_historico_small.png" alt="Obtener Listado de jugadas validadas" title="Obtener Listado de jugadas validadas"> Listar Jugadas Validadas
		
		<!--<button id="comprobarJugada">Comprobar Jugada</button> &nbsp;&nbsp;&nbsp;-->
		<!--<a id="obtenerResumen">Obtener Histórico de Jugadas (Puntuaciones)</a> -->
		<!--<button id="rendirse">Rendirse</button>-->
		<span id="letrasensaco"></span><br>
	</div>	

	<div id="paneljugador" class="scorebackground_on">
			<div id="jugadortag">JUGADOR</div> 
			<div id="tpuntosjugador">0</div>			
			<div id="paneljugadoropt">Opciones:<br>
				<!--<button id="rellenarLetrasju">Fill Letras</button>-->
				<span class="tag" id="rellenarLetrasju">Rellenar Letras</span>
				<!--<input id="cambiarLetraju" type="image" src="images/saco1.png" title="Rendirse" alt="Cambiar la letra seleccionada">--> 
				<span class="tag" id="cambiarLetraju">Cambiar Letra</span>
				<!--<input id="cambiarTodasju" type="image" src="images/saco.png" title="Rendirse" alt="Cambiar Todas las letras">--> 
				<span class="tag" id="cambiarTodasju">Cambiar Letras</span>
			</div>
	</div>

	<div id="paneladversario" class="scorebackground_off">
				<div id="adversariotag">ADVERSARIO</div> 
				<div id="tpuntosadversario">0</div>
				<div id="paneladversarioopt">Opciones:<br>
					<!--<button id="rellenarLetrasad">Fill Letras</button><br>-->
					<span class="tag" id="rellenarLetrasad">Rellenar Letras</span>
					<!--<input id="cambiarLetraad" type="image" src="images/saco1.png" title="Rendirse" alt="Cambiar la letra seleccionada">-->
					<span class="tag" id="cambiarLetraad">Cambiar Letra</span>
					<!--<input id="cambiarTodasad" type="image" src="images/saco.png" title="Rendirse" alt="Cambiar Todas las letras">-->
					<span class="tag" id="cambiarTodasad">Cambiar Letras</span>
				</div>
	</div>	

	<div id="jugador" class="jugador_on">	
		<span id="debug1" class="debug_off"><tt id="px">0</tt>X<tt id="py">0</tt></span> <br>
		<div id="fondoletrasju" class="fondoletrasbackground_on"><canvas id="letrasJugador" width="500" height="100"></canvas></div>
		
	</div>	

	<div id="adversario" class="adversario_off">
			
		<span id="debug2" class="debug_off"><tt id="ax">0</tt>X<tt id="ay">0</tt></span> <br>
	 	<div id="fondoletrasad" class="fondoletrasbackground_off"><canvas id="letrasAdversario" width="500" height="100"></canvas></div><br><br>

        <div id="resultado"></div>		
		<!--<span id="debug3" class="debug_off"><tt id="x">0</tt>X<tt id="y">0</tt><br/><tt id="info"></tt></span>-->
	</div>

	<ol class="word"></ol>	
</div>');







// Finish the page
echo $OUTPUT->footer();
