<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">

       	<script src="js/jquery.js" type="text/javascript"></script>
	<script src="js/scramble1.js" type="text/javascript"></script>





    </head>
    <body>

  	<input type="text" id="busqueda" />
             
	<div id="resultado"></div>

</body></html>
