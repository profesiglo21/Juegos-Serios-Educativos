<?php
header('Content-Type: text/plain; charset=utf-8');
/*$buscar = $_POST['palabra'];
$diclang = $_POST['diclanguage'];
*/

$buscar = 'risa';
$diclang = 'es';

echo $diclang;
die();

$contar = 0;

/** El nombre de tu base de datos */
define('DB_NAME', 'test');

/** Tu nombre de usuario de MySQL */
define('DB_USER', 'root');

/** Tu contraseña de MySQL */
define('DB_PASSWORD', '123456');

/** Host de MySQL (es muy probable que no necesites cambiarlo) */
define('DB_HOST', 'localhost');

/** Codificación de caracteres para la base de datos. */
define('DB_CHARSET', 'utf8');

	function conectarBD()
    {
		/* create a connection object which is not connected */
		$mysqli = mysqli_init();

		/* set connection options */
		$mysqli->options(MYSQLI_OPT_LOCAL_INFILE, true);

		/* connect to server */
		$mysqli->real_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
		$mysqli->set_charset(DB_CHARSET);
			
		/* check connection */
		if (mysqli_connect_errno()) {
				printf("Conexión fallida: %s\n", mysqli_connect_error());
				exit();
		}		
		return $mysqli;
	}


	if(isset($buscar) && isset($diclang)) {
	    $conexion = conectarBD();

		$arrayPalabras = explode(',',$buscar);
		for ($i = 0; $i <= count($arrayPalabras)-1; $i++) {
		   buscarPalabra($arrayPalabras[$i], $diclang);
		}
	
		if (count($arrayPalabras) == $contar){
			echo "1";               
		}		             
		else{
			echo "0"; 
        }
    }
 
    function buscarPalabra($b, $diclang)
    {
		global $contar;
		global $conexion;
			
		$sql = "SELECT * FROM mydiccionario_". $diclang. "new WHERE palabra = '".$b."'";
		echo $sql;
		die();
		if ($result = $conexion->query($sql)) {
			/* determinar el número de filas del resultado */
			$row_cnt = $result->num_rows;			   
			$result->close();
		}

		if($row_cnt > 0)
		    $contar++;
		
		
	}	
      }     
      
      
  
    $conexion->close();

?>
