<?php
 
      $buscar = $_POST['b'];
      //$buscar = "salim";

       
      if(!empty($buscar)) {
            buscar($buscar);
      }
       
      function buscar($b) {
            $con = mysql_connect('localhost','root', '123456');
            mysql_select_db('test', $con);
       
            $sql = mysql_query("SELECT * FROM mydiccionario_es WHERE palabra = '".$b."'",$con);
             
            $contar = mysql_num_rows($sql);
             
            if($contar == 0){
                  echo "0";
            }else{
                  echo "1";
            }
      }
       
?>
