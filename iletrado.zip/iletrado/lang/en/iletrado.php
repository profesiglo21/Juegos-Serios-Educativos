<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.


/**
 * English strings for iletrado
 *
 * You can have a rather longer description of the file as well,
 * if you like, and it can span multiple lines.
 *
 * @package    mod_iletrado
 * @copyright  2011 Your Name
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['modulename'] = 'iletrado';
$string['modulenameplural'] = 'iletrados';
$string['modulename_help'] = 'Use the iletrado module for... | The iletrado module allows...';
$string['iletradofieldset'] = 'Custom example fieldset';
$string['iletradoname'] = 'iletrado name';
$string['iletradoname_help'] = 'This is the content of the help tooltip associated with the iletradoname field. Markdown syntax is supported.';
$string['iletrado'] = 'iletrado';
$string['pluginadministration'] = 'iletrado administration';
$string['pluginname'] = 'iletrado';


$string['select_gametype'] = 'Select el tipo de Juego:';
$string['gametypehelp'] = 'Starting Level of the game: 1-10 where 1 is the slowest and 10 the fastest';

$string['select_diccionariolang'] = 'Select the diccionary language:';
$string['diccionariolanghelp'] = 'Select the diccionary language:';

$string['option_type_clasico'] = 'Clasico';
$string['option_type_adversario'] ='Adversario';

$string['option_dic_castellano'] = 'Castellano';
$string['option_dic_ingles'] = 'Inglés';