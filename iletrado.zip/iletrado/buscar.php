<?php

header('Content-Type: text/plain; charset=utf-8');
require_once(dirname(dirname(dirname(__FILE__))).'/config.php');

//risa,tema,rima,fan
$buscar = $_POST['palabra'];
$diclang = $_POST['diclanguage'];

$buscar = "risa,tema,rima,fan";
$diclang = "es";

//$buscar = "perro,camión,ábaco";
//noencontrados = "tema,risa"
$contar = 0;
/** El nombre de tu base de datos */
define('DB_NAME', $CFG->dbname);

/** Tu nombre de usuario de MySQL */
define('DB_USER', $CFG->dbuser);

/** Tu contraseña de MySQL */
define('DB_PASSWORD', $CFG->dbpass);

/** Host de MySQL (es muy probable que no necesites cambiarlo) */
define('DB_HOST', $CFG->dbhost);

/** Codificación de caracteres para la base de datos. */
define('DB_CHARSET', 'utf8');

function conectarBD()
    {
		/* create a connection object which is not connected */
		$mysqli = mysqli_init();

		/* set connection options */
		$mysqli->options(MYSQLI_OPT_LOCAL_INFILE, true);

		/* connect to server */
		$mysqli->real_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
		$mysqli->set_charset(DB_CHARSET);
			
		/* check connection */
		if (mysqli_connect_errno()) {
				printf("Conexión fallida: %s\n", mysqli_connect_error());
				exit();
		}		
		return $mysqli;
	}

	 
if(isset($buscar) && isset($diclang) ) {
	$arrayPalabras = explode(',',$buscar);
	for ($i = 0; $i <= count($arrayPalabras)-1; $i++) {
	   buscarPalabra($arrayPalabras[$i], $diclang);
	}
	
	if (count($arrayPalabras) == $contar){
		echo "1";
                //printf("Todas buscada OK: %s existe? %d\n", count($arrayPalabras), $contar);
	}
        else{
		echo "0";
		//printf("Todas buscados NO OK: %s existe? %d\n", count($arrayPalabras), $contar);
	}          
}
   

 
function buscarPalabra($b, $diclang)
{
	global $contar;
	$conexion = conectarBD();
	$sql = "SELECT * FROM mydiccionario_". $diclang. " WHERE palabra = '".$b."'";
  
	
	if ($result = $conexion->query($sql)) {

	    /* determinar el número de filas del resultado */
	    $row_cnt = $result->num_rows;
            //printf("La palabra buscada: %s existe? %d\n", $b, $row_cnt);
 	    /* cerrar el resultset */
	    $result->close();
	}


	if($row_cnt > 0){	
		$contar++;
		//printf("Contador %d\n", $contar);
	}
	else {
	    if($diclang == 'es') 
		buscarPalabraRAE($b, $diclang);
	}

}

function buscarPalabraRAE($b, $diclang)
    {
    	global $contar;
    	$conexion = conectarBD();
        $noseencuentra = 'no est&aacute; registrada en el Diccionario';

        $url = "http://dle.rae.es/srv/search?w=" . $b;

       ini_set("default_socket_timeout","05");
       set_time_limit(5);
       $f=fopen($url,"r");
       $r=fread($f,1000);
       fclose($f);
       if(strlen($r)>1) {
      
       		$html = file_get_contents($url);
	        $pos1 = stripos($html, $noseencuentra);
	       
	        if ($pos1 === false) {
	            $contar++; 
				
				$isql = "INSERT INTO mydiccionario_". $diclang. " (palabra) VALUES ('".$b."')";
	          		
				$result = $conexion->query($isql);
                         
	        }
       }
       else {      
       	return;
       }
		
	

		
	
		
        
        
    }



       
?>
